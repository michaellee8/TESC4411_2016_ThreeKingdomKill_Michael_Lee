/*    */ package comp;
/*    */ 
/*    */ public enum Card {
/*  4 */   Attack(0, "攻擊牌", 0),  Defense(1, "抵擋牌", 0),  Heal(2, "補藥牌", 0), 
/*  5 */   Agility(3, "敏捷牌", 1),  Axe(4, "戰斧牌", 1),  Vitality(5, "生命之鎧牌", 1),  Shield(6, "戰盾牌", 1), 
/*  6 */   Repeal(7, "消除牌", 2),  Grab(8, "搶奪牌", 2),  RepealX(9, "消除牌", 2);
/*    */   
/*    */   public final int id;
/*    */   public final String chiName;
/*    */   final int type;
/*    */   
/*    */   private Card(int id, String name, int type) {
/* 13 */     this.id = id;
/* 14 */     this.chiName = name;
/* 15 */     this.type = type;
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\Card.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */