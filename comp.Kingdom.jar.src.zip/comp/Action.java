/*    */ package comp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */  enum Action
/*    */ {
/* 37 */   Draw("抽牌"),  Attack("攻撃"),  Defense("抵抗"),  Heal("補血"),  Func("功能牌"),  Debuff("除益"),  Spec("技能"),  Noting("待機"),  Cancel(
/* 38 */     "取消");
/*    */   
/*    */   final String chiName;
/*    */   
/*    */   private Action(String cn) {
/* 43 */     this.chiName = cn;
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\Action.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */