/*    */ package comp;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class HeroZhouYu extends Hero {
/*    */   public final void join(int index) {
/*  7 */     GameMaster master = GameMaster.getInstance();
/*  8 */     GameMaster.Player player = master.players[index];
/*  9 */     player.attList.add(new Attributes("周瑜", 300, 1, 3, 0, 0, null));
/* 10 */     player.heroes.add(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\HeroZhouYu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */