/*    */ package comp;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.sound.sampled.AudioFormat;
/*    */ import javax.sound.sampled.AudioInputStream;
/*    */ import javax.sound.sampled.AudioSystem;
/*    */ import javax.sound.sampled.Clip;
/*    */ import javax.sound.sampled.DataLine.Info;
/*    */ import javax.sound.sampled.LineUnavailableException;
/*    */ import javax.sound.sampled.UnsupportedAudioFileException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SoundPlayer
/*    */   implements SoundPlayerIF
/*    */ {
/* 25 */   Map<String, Clip> clips = null;
/*    */   
/*    */   SoundPlayer() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
/* 28 */     this.clips = new HashMap();
/*    */     
/*    */ 
/* 31 */     addClip("bg", "raw/bgMusic.wav");
/* 32 */     addClip("attack", "raw/attack.wav");
/* 33 */     addClip("swallow", "raw/swallow.wav");
/* 34 */     addClip("blood", "raw/blood.wav");
/* 35 */     addClip("ha", "raw/ha.wav");
/* 36 */     addClip("hurt1", "raw/hurt1.wav");
/* 37 */     addClip("hurt2", "raw/hurt2.wav");
/*    */     
/* 39 */     addClip("reflect", "raw/reflect.wav");
/* 40 */     addClip("crash", "raw/crash.wav");
/* 41 */     addClip("cardFlip", "raw/cardFlip.wav");
/* 42 */     addClip("load", "raw/load.wav");
/*    */     
/* 44 */     addClip("unload", "raw/unload.wav");
/* 45 */     addClip("horse", "raw/horse.wav");
/* 46 */     addClip("win", "raw/win.wav");
/*    */     
/* 48 */     addClip("lightning", "raw/thunder.wav");
/*    */   }
/*    */   
/*    */   private void addClip(String key, String soundFile) throws UnsupportedAudioFileException, IOException, LineUnavailableException
/*    */   {
/* 53 */     AudioInputStream stream = AudioSystem.getAudioInputStream(new File(soundFile));
/* 54 */     AudioFormat format = stream.getFormat();
/* 55 */     DataLine.Info info = new DataLine.Info(Clip.class, format);
/* 56 */     Clip clip = (Clip)AudioSystem.getLine(info);
/* 57 */     clip.open(stream);
/* 58 */     this.clips.put(key, clip);
/*    */   }
/*    */   
/*    */   public void playA(String key) {
/* 62 */     pause(key);
/* 63 */     ((Clip)this.clips.get(key)).setFramePosition(0);
/* 64 */     ((Clip)this.clips.get(key)).start();
/*    */   }
/*    */   
/*    */   public void playLoop(String key) {
/* 68 */     ((Clip)this.clips.get(key)).start();
/* 69 */     ((Clip)this.clips.get(key)).loop(-1);
/*    */   }
/*    */   
/*    */   public void pause(String key) {
/* 73 */     if (((Clip)this.clips.get(key)).isActive())
/* 74 */       ((Clip)this.clips.get(key)).stop();
/*    */   }
/*    */   
/*    */   public void stopAll() {
/* 78 */     for (Clip c : this.clips.values()) {
/* 79 */       c.stop();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\SoundPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */