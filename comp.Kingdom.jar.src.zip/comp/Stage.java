/*    */ package comp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */  enum Stage
/*    */ {
/* 10 */   Drawing("抽牌"),  Action("行動"),  BeingAttack("受攻撃"),  Discarding("棄牌");
/*    */   
/*    */   final String chiName;
/*    */   
/*    */   private Stage(String chiName) {
/* 15 */     this.chiName = chiName;
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\Stage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */