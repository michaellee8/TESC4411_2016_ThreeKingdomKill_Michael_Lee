/*     */ package comp;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnimationPlayer
/*     */   extends JComponent
/*     */   implements Runnable
/*     */ {
/*     */   static final byte Canvas_Top = 1;
/*     */   static final byte Canvas_Middle = 2;
/*     */   static final byte Canvas_Bottom = 4;
/*     */   static final byte Canvas_Left = 8;
/*     */   static final byte Canvas_Center = 16;
/*     */   static final byte Canvas_Right = 32;
/*  75 */   JPanel ctrlPanel = new JPanel();
/*  76 */   JFrame window = null;
/*  77 */   Map<String, Image> images = null;
/*     */   Font font;
/*     */   Font fontA;
/*  80 */   Font fontB; Font fontC; Font fontD; Font fontE; Font fontF; Color colorA; Color colorB; Color colorC; int speed = 1;
/*     */   
/*     */   private boolean render;
/*  83 */   int round = 0;
/*  84 */   boolean[] visible = { true, true };
/*     */   
/*  86 */   String[] playerNames = new String[2];
/*  87 */   String[][] heroNames = new String[2][];
/*  88 */   int[][] hp_maxHps = new int[2][2];
/*  89 */   int[] attackTimes = new int[2];
/*  90 */   int[] drawCards = new int[2];
/*  91 */   int count_discardedCards = 0;
/*     */   
/*  93 */   ImageObject imgBg = null;
/*  94 */   TextObject txtRound = null;
/*  95 */   ImageObject[][] imgHeroes = new ImageObject[2][];
/*  96 */   TextObject txtCards = null;
/*  97 */   ImageObject imgDiscardedCard = null;
/*  98 */   ImageObject imgSword = null;
/*  99 */   ImageObject imgSpear = null; ImageObject imgShield = null;
/* 100 */   ImageObject imgSpearNormal = null; ImageObject imgShieldNormal = null;
/* 101 */   ImageObject imgSpearCritical = null; ImageObject imgShieldReflect = null;
/* 102 */   ImageObject imgAttacker = null; ImageObject imgDefender = null;
/* 103 */   ImageObject imgCard = null;
/* 104 */   ImageObject imgEnd = null;
/* 105 */   TextObject txtEnd = null;
/* 106 */   TextObject txtMsg = null;
/* 107 */   TextObject[] txtHp = new TextObject[2];
/*     */   
/*     */ 
/* 110 */   ArrayList<Card> discardedCards = new ArrayList();
/* 111 */   ArrayList<ImageObject>[] handCards = { new ArrayList(), 
/* 112 */     new ArrayList() };
/* 113 */   ArrayList<ImageObject>[] buffs = { new ArrayList(), new ArrayList() };
/* 114 */   ArrayList<VisualObject> voList = new ArrayList();
/*     */   
/* 116 */   ArrayList<VisualObject> buttons = new ArrayList();
/*     */   
/*     */   private HurtEffectObject hurtEffectObj;
/*     */   private LightningEffectObject lightningEffectObj;
/* 120 */   SoundPlayerIF soundPlayer = null;
/* 121 */   SoundPlayer soundPlayerNormal = null;
/* 122 */   SoundPlayerDummy soundPlayerDummy = null;
/*     */   
/*     */   public AnimationPlayer() {
/* 125 */     addMouseListener(new AniMouseListener());
/*     */     try
/*     */     {
/* 128 */       this.soundPlayer = (this.soundPlayerNormal = new SoundPlayer());
/* 129 */       this.soundPlayerDummy = new SoundPlayerDummy();
/*     */     } catch (LineUnavailableException|IOException|UnsupportedAudioFileException e) {
/* 131 */       e.printStackTrace();
/*     */     }
/*     */     try
/*     */     {
/* 135 */       this.font = Font.createFont(0, new File("raw/Symbola.ttf")).deriveFont(14.0F);
/* 136 */       this.fontA = Font.createFont(0, new File("raw/defaultFont.ttf")).deriveFont(24.0F);
/* 137 */       this.fontB = Font.createFont(0, new File("raw/defaultFont.ttf")).deriveFont(48.0F);
/* 138 */       this.fontC = Font.createFont(0, new File("raw/wtcc02.ttf")).deriveFont(150.0F);
/* 139 */       this.fontD = Font.createFont(0, new File("raw/wtcc02.ttf")).deriveFont(24.0F);
/* 140 */       this.fontE = Font.createFont(0, new File("raw/wtcc02.ttf")).deriveFont(48.0F);
/* 141 */       this.fontF = Font.createFont(0, new File("raw/defaultFont.ttf")).deriveFont(150.0F);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 145 */       ex.printStackTrace();
/*     */     }
/*     */     
/* 148 */     this.colorA = Color.WHITE;
/* 149 */     this.colorB = Color.YELLOW;
/* 150 */     this.colorC = Color.GRAY;
/*     */     
/* 152 */     this.images = new HashMap();
/* 153 */     this.images.put("bg", Toolkit.getDefaultToolkit().getImage("images/bg.jpg"));
/* 154 */     this.images.put("Attack", Toolkit.getDefaultToolkit().getImage("images/attackCard.png"));
/* 155 */     this.images.put("Defense", Toolkit.getDefaultToolkit().getImage("images/defenseCard.png"));
/* 156 */     this.images.put("Heal", Toolkit.getDefaultToolkit().getImage("images/healCard.png"));
/* 157 */     this.images.put("Agility", Toolkit.getDefaultToolkit().getImage("images/agilityCard.png"));
/* 158 */     this.images.put("Vitality", Toolkit.getDefaultToolkit().getImage("images/vitalityCard.png"));
/* 159 */     this.images.put("Repeal", Toolkit.getDefaultToolkit().getImage("images/repealCard.png"));
/* 160 */     this.images.put("Grab", Toolkit.getDefaultToolkit().getImage("images/grabCard.png"));
/* 161 */     this.images.put("Shield", Toolkit.getDefaultToolkit().getImage("images/shieldCard.png"));
/* 162 */     this.images.put("Axe", Toolkit.getDefaultToolkit().getImage("images/strengthCard.png"));
/* 163 */     this.images.put("Attacker", Toolkit.getDefaultToolkit().getImage("images/attacker.png"));
/* 164 */     this.images.put("Defender", Toolkit.getDefaultToolkit().getImage("images/defender.png"));
/* 165 */     this.images.put("End0", Toolkit.getDefaultToolkit().getImage("images/end0.png"));
/* 166 */     this.images.put("End1", Toolkit.getDefaultToolkit().getImage("images/end1.png"));
/* 167 */     this.images.put("Card", Toolkit.getDefaultToolkit().getImage("images/card.png"));
/* 168 */     this.images.put("Power", Toolkit.getDefaultToolkit().getImage("images/power.png"));
/* 169 */     this.images.put("Sword", Toolkit.getDefaultToolkit().getImage("images/sword.png"));
/* 170 */     this.images.put("aniSpear", Toolkit.getDefaultToolkit().getImage("images/spear.png"));
/* 171 */     this.images.put("aniSpearCritical", Toolkit.getDefaultToolkit().getImage("images/spearCritical.png"));
/* 172 */     this.images.put("aniShield", Toolkit.getDefaultToolkit().getImage("images/shield.png"));
/* 173 */     this.images.put("aniShieldReflect", Toolkit.getDefaultToolkit().getImage("images/shieldReflect.png"));
/* 174 */     this.images.put("RepealX", Toolkit.getDefaultToolkit().getImage("images/repealXCard.png"));
/*     */     
/* 176 */     this.images.put("甘寧", Toolkit.getDefaultToolkit().getImage("images/HeroGanNing.png"));
/* 177 */     this.images.put("黄蓋", Toolkit.getDefaultToolkit().getImage("images/HeroHuangGai.png"));
/* 178 */     this.images.put("馬超", Toolkit.getDefaultToolkit().getImage("images/HeroMaChao.png"));
/* 179 */     this.images.put("夏侯惇", Toolkit.getDefaultToolkit().getImage("images/HeroXiaHouDun.png"));
/* 180 */     this.images.put("許褚", Toolkit.getDefaultToolkit().getImage("images/HeroXuChu.png"));
/* 181 */     this.images.put("許褚2", Toolkit.getDefaultToolkit().getImage("images/HeroXuChu2.png"));
/* 182 */     this.images.put("張飛", Toolkit.getDefaultToolkit().getImage("images/HeroZhangFei.png"));
/* 183 */     this.images.put("張遼", Toolkit.getDefaultToolkit().getImage("images/HeroZhangLiao.png"));
/* 184 */     this.images.put("趙雲", Toolkit.getDefaultToolkit().getImage("images/HeroZhaoYun.png"));
/* 185 */     this.images.put("周瑜", Toolkit.getDefaultToolkit().getImage("images/HeroZhouYu.png"));
/*     */     
/* 187 */     this.window = new JFrame("三國亂殺");
/* 188 */     this.window.setDefaultCloseOperation(3);
/* 189 */     this.window.setSize(1024, 800);
/* 190 */     this.window.setResizable(false);
/* 191 */     this.window.setLayout(new BorderLayout());
/* 192 */     this.window.getContentPane().add(this, "Center");
/* 193 */     this.window.getContentPane().add(this.ctrlPanel, "South");
/*     */     
/* 195 */     this.window.setUndecorated(true);
/* 196 */     this.window.setExtendedState(this.window.getExtendedState() | 0x6);
/* 197 */     this.window.setVisible(true);
/*     */     
/* 199 */     this.imgBg = new ImageObject((Image)this.images.get("bg"), this);
/* 200 */     this.imgBg.setPosition(0.0F, 0.0F, new int[] { 16, 2 });
/* 201 */     this.imgDiscardedCard = new ImageObject(null, this);
/*     */     
/* 203 */     this.txtRound = new TextObject("", this.fontF, this.colorC, 0.0F, 0.0F, null, null, this);
/* 204 */     this.txtRound.setPosition(0.0F, 0.0F, new int[] { 16, 2 });
/* 205 */     this.txtRound.alpha = 0.75F;
/* 206 */     this.voList.add(this.txtRound);
/*     */     
/* 208 */     this.imgShield = (this.imgShieldNormal = new ImageObject((Image)this.images.get("aniShield"), this));
/* 209 */     this.imgShieldNormal.setPosition(0.0F, 0.0F, new int[] { 2 });
/* 210 */     this.imgShieldNormal.alpha = 0.0F;
/* 211 */     this.voList.add(this.imgShieldNormal);
/*     */     
/* 213 */     this.imgShieldReflect = new ImageObject((Image)this.images.get("aniShieldReflect"), this);
/* 214 */     this.imgShieldReflect.setPosition(0.0F, 0.0F, new int[] { 2 });
/* 215 */     this.imgShieldReflect.alpha = 0.0F;
/* 216 */     this.voList.add(this.imgShieldReflect);
/*     */     
/* 218 */     this.imgSpear = (this.imgSpearNormal = new ImageObject((Image)this.images.get("aniSpear"), this));
/* 219 */     this.imgSpearNormal.setPosition(0.0F, 0.0F, new int[] { 2 });
/* 220 */     this.imgSpearNormal.alpha = 0.0F;
/* 221 */     this.voList.add(this.imgSpearNormal);
/*     */     
/* 223 */     this.imgSpearCritical = new ImageObject((Image)this.images.get("aniSpearCritical"), this);
/* 224 */     this.imgSpearCritical.setPosition(0.0F, 0.0F, new int[] { 2 });
/* 225 */     this.imgSpearCritical.alpha = 0.0F;
/* 226 */     this.voList.add(this.imgSpearCritical);
/*     */     
/* 228 */     this.imgCard = new ImageObject((Image)this.images.get("Card"), this);
/* 229 */     this.imgEnd = new ImageObject(null, this);
/* 230 */     this.imgEnd.zoom = 0.0D;
/* 231 */     this.imgEnd.alpha = 0.0F;
/* 232 */     this.imgEnd.setPosition(0.0F, 0.0F, new int[] { 16, 2 });
/* 233 */     this.txtEnd = new TextObject("", this.fontC, this.colorA, 0.0F, 0.0F, null, null, this);
/* 234 */     this.txtEnd.setPosition(0.0F, 100.0F, new int[] { 16 });
/*     */     
/* 236 */     this.txtCards = new TextObject("", this.fontD, this.colorA, 0.0F, 0.0F, null, null, this);
/* 237 */     this.txtCards.setPosition(0.0F, 140.0F, new int[] { 16, 4 });
/* 238 */     this.voList.add(this.txtCards);
/*     */     
/* 240 */     this.txtMsg = new TextObject("", this.fontE, this.colorB, 0.0F, 0.0F, null, null, this);
/* 241 */     this.txtMsg.setPosition(0.0F, 0.0F, new int[] { 16, 2 });
/* 242 */     this.txtMsg.alpha = 0.0F;
/* 243 */     this.voList.add(this.txtMsg);
/*     */     
/* 245 */     this.imgSword = new ImageObject((Image)this.images.get("Sword"), this);
/*     */     
/* 247 */     this.imgAttacker = new ImageObject((Image)this.images.get("Attacker"), this);
/* 248 */     this.imgAttacker.alpha = 0.0F;
/* 249 */     this.imgDefender = new ImageObject((Image)this.images.get("Defender"), this);
/* 250 */     this.imgDefender.alpha = 0.0F;
/* 251 */     this.voList.add(this.imgAttacker);
/* 252 */     this.voList.add(this.imgDefender);
/*     */     
/* 254 */     for (int i = 0; i < 2; i++) {
/* 255 */       this.txtHp[i] = new TextObject("", this.fontA, Color.BLACK, 0.0F, 0.0F, Color.WHITE, Color.CYAN, this);
/* 256 */       this.txtHp[i].setPosition(0.0F, 80.0F, new int[] { i == 0 ? 8 : 32 });
/*     */     }
/*     */     
/* 259 */     this.hurtEffectObj = new HurtEffectObject(this);
/* 260 */     this.hurtEffectObj.alpha = 0.0F;
/*     */     
/* 262 */     this.lightningEffectObj = new LightningEffectObject(this);
/* 263 */     this.lightningEffectObj.alpha = 0.0F;
/*     */   }
/*     */   
/*     */   public void idle(int msec)
/*     */   {
/*     */     try {
/* 269 */       double ms = (1.0D - 0.2D * this.speed) * msec;
/* 270 */       Thread.sleep((int)Math.round(ms));
/*     */     } catch (InterruptedException e) {
/* 272 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private void aniAddCard(ImageObject obj) {
/* 277 */     obj.zoom = 0.0D;
/* 278 */     obj.alpha = 1.0F;
/* 279 */     while (obj.zoom < 1.5D)
/*     */     {
/* 281 */       idle(10);
/* 282 */       obj.zoom += 0.1D;
/*     */     }
/* 284 */     obj.zoom = 1.0D;
/*     */     
/* 286 */     idle(10);
/*     */   }
/*     */   
/*     */   private void aniRemoveCard(ImageObject obj) {
/* 290 */     while (obj.zoom < 1.5D)
/*     */     {
/* 292 */       idle(10);
/* 293 */       obj.zoom += 0.1D;
/*     */     }
/* 295 */     while (obj.zoom > 0.0D)
/*     */     {
/* 297 */       idle(10);
/* 298 */       obj.zoom -= 0.1D;
/*     */     }
/* 300 */     obj.alpha = 0.0F;
/*     */   }
/*     */   
/*     */   private void aniUseCard(ImageObject obj) {
/* 304 */     for (int i = 0; i < 20; i++) {
/* 305 */       obj.x += 5.0F;
/*     */       
/* 307 */       idle(10);
/*     */     }
/* 309 */     aniRemoveCard(obj);
/*     */     
/* 311 */     idle(10);
/*     */   }
/*     */   
/*     */   private void aniHurt(int index) {
/* 315 */     if (index == 1) {
/* 316 */       this.hurtEffectObj.posX = 32;
/*     */     } else
/* 318 */       this.hurtEffectObj.posX = 8;
/* 319 */     this.hurtEffectObj.alpha = 1.0F;
/*     */     
/* 321 */     idle(100);
/* 322 */     while (this.hurtEffectObj.alpha > 0.0F) {
/* 323 */       this.hurtEffectObj.alpha -= 0.1F;
/*     */       
/* 325 */       idle(100);
/*     */     }
/* 327 */     this.hurtEffectObj.alpha = 0.0F;
/*     */   }
/*     */   
/*     */   public void animate(String animation) {
/* 331 */     if (animation.startsWith("/")) {
/* 332 */       return;
/*     */     }
/* 334 */     String[] values = animation.split("\\|");
/* 335 */     int type = Integer.parseInt(values[0]);
/* 336 */     ImageObject obj; switch (type) {
/*     */     case 100: 
/* 338 */       this.txtCards.text = String.format("未發出的牌共有 %s 張，被丟棄的牌共有 %s 張。", new Object[] { values[1], values[2] });
/* 339 */       System.out.println(String.format("未發出的牌共有 %s 張，被丟棄的牌共有 %s 張。", new Object[] { values[1], values[2] }));
/*     */       
/* 341 */       idle(100);
/* 342 */       break;
/*     */     
/*     */ 
/*     */     case 101: 
/* 346 */       if (values[1].equals("clear")) {
/* 347 */         this.discardedCards.clear();
/*     */       } else {
/* 349 */         int index = Integer.parseInt(values[1]);
/*     */         
/*     */ 
/* 352 */         int w = ((Image)this.images.get("Card")).getWidth(null);
/* 353 */         int x = getWidth() / 2 - (this.discardedCards.size() - 1) * 20 / 2;
/*     */         
/* 355 */         obj = new ImageObject((Image)this.images.get(Card.values()[index].name()), this);
/* 356 */         obj.setPosition(x + 20 * (this.discardedCards.size() - 1), 10 + 20 * this.discardedCards.size() % 2, new int[] { 4 });
/* 357 */         this.voList.add(obj);
/* 358 */         aniAddCard(obj);
/* 359 */         this.voList.remove(obj);
/* 360 */         this.discardedCards.add(Card.values()[index]);
/* 361 */         System.out.println(String.format("【%s】掉到回收區。", new Object[] { Card.values()[index].chiName }));
/*     */       }
/*     */       
/* 364 */       idle(100);
/* 365 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case 102: 
/* 370 */       int index = Integer.parseInt(values[1]);
/* 371 */       Card card = Card.values()[Integer.parseInt(values[2])];
/* 372 */       ImageObject obj = new ImageObject((Image)this.images.get(card.name()), this);
/* 373 */       obj.setPosition(250.0F, 0.0F, new int[] { index == 0 ? 8 : 32 });
/* 374 */       obj.tag = card;
/* 375 */       this.handCards[index].add(obj);
/* 376 */       System.out.println(String.format("【%s】 得到 【%s】。", new Object[] { this.playerNames[index], card.chiName }));
/* 377 */       this.soundPlayer.playA("cardFlip");
/* 378 */       aniAddCard(obj);
/*     */       
/* 380 */       idle(100);
/* 381 */       break;
/*     */     
/*     */     case 104: 
/* 384 */       int index = Integer.parseInt(values[1]);
/* 385 */       Card card = Card.values()[Integer.parseInt(values[2])];
/* 386 */       for (VisualObject obj : this.handCards[index]) {
/* 387 */         if ((Card)obj.tag == card) {
/* 388 */           this.soundPlayer.playA("cardFlip");
/* 389 */           aniUseCard((ImageObject)obj);
/* 390 */           this.handCards[index].remove(obj);
/* 391 */           System.out.println(String.format("【%s】 使用 【%s】。", new Object[] { this.playerNames[index], card.chiName }));
/* 392 */           break;
/*     */         }
/*     */       }
/*     */       
/* 396 */       idle(100);
/* 397 */       break;
/*     */     
/*     */     case 103: 
/* 400 */       int index = Integer.parseInt(values[1]);
/* 401 */       Card card = Card.values()[Integer.parseInt(values[2])];
/* 402 */       for (VisualObject obj : this.handCards[index]) {
/* 403 */         if ((Card)obj.tag == card) {
/* 404 */           this.soundPlayer.playA("cardFlip");
/* 405 */           aniRemoveCard((ImageObject)obj);
/* 406 */           this.handCards[index].remove(obj);
/* 407 */           System.out.println(String.format("【%s】的【%s】被取出。", new Object[] { this.playerNames[index], card.chiName }));
/* 408 */           break;
/*     */         }
/*     */       }
/*     */       
/* 412 */       idle(100);
/* 413 */       break;
/*     */     
/*     */     case 200: 
/* 416 */       String msg = String.format("作出錯誤行動．%s", new Object[] { values[1] });
/* 417 */       this.txtMsg.text = msg;
/* 418 */       this.txtMsg.alpha = 1.0F;
/* 419 */       idle(200);
/* 420 */       while (this.txtMsg.alpha > 0.0F) {
/* 421 */         this.txtMsg.alpha -= 0.1F;
/* 422 */         idle(100);
/*     */       }
/* 424 */       System.out.println(msg);
/* 425 */       break;
/*     */     
/*     */     case 201: 
/* 428 */       System.out.println(String.format("第 %s 回合。", new Object[] { values[1] }));
/*     */       
/* 430 */       this.round = Integer.parseInt(values[1]);
/* 431 */       this.txtRound.text = String.format("第%s\n回", new Object[] { values[1] });
/* 432 */       idle(100);
/* 433 */       break;
/*     */     
/*     */ 
/*     */     case 202: 
/* 437 */       int index = Integer.parseInt(values[1]);
/*     */       
/* 439 */       if (index == 0) {
/* 440 */         this.imgAttacker.setPosition(150.0F, 300.0F, new int[] { 8, 4 });
/* 441 */         this.imgDefender.setPosition(150.0F, 300.0F, new int[] { 32, 4 });
/*     */       } else {
/* 443 */         this.imgAttacker.setPosition(150.0F, 300.0F, new int[] { 32, 4 });
/* 444 */         this.imgDefender.setPosition(150.0F, 300.0F, new int[] { 8, 4 });
/*     */       }
/* 446 */       this.imgAttacker.alpha = (this.imgDefender.alpha = 1.0F);
/* 447 */       System.out.println(String.format("由 【%s】 作為攻方。", new Object[] { this.playerNames[index] }));
/*     */       
/* 449 */       idle(100);
/* 450 */       break;
/*     */     
/*     */     case 203: 
/* 453 */       int index = Integer.parseInt(values[1]);
/* 454 */       TextObject obj = new TextObject(values[2], this.fontD, this.colorA, 0.0F, 0.0F, null, null, this);
/* 455 */       obj.setPosition(60.0F, 35.0F, new int[] { index == 0 ? 8 : 32 });
/* 456 */       obj.strokeColor = null;
/* 457 */       this.voList.add(obj);
/* 458 */       System.out.println(String.format("【%s】 玩家名稱為【%s】。", new Object[] { index == 0 ? "左方" : "右方", values[2] }));
/* 459 */       this.playerNames[index] = values[2];
/* 460 */       break;
/*     */     
/*     */ 
/*     */     case 205: 
/* 464 */       int index = Integer.parseInt(values[1]);
/*     */       
/* 466 */       this.heroNames[index] = new String[values.length - 2];
/* 467 */       this.imgHeroes[index] = new ImageObject[values.length - 2];
/* 468 */       for (int i = 0; i < values.length - 2; i++) {
/* 469 */         this.heroNames[index][i] = values[(i + 2)];
/* 470 */         this.imgHeroes[index][i] = new ImageObject((Image)this.images.get(values[(i + 2)]), this);
/* 471 */         this.imgHeroes[index][i].setPosition(80 + i * 10, 140 + 10 * i, new int[] { index == 0 ? 8 : 32 });
/*     */       }
/* 473 */       System.out.println(String.format("【%s】 的英雄為 【%s】。", new Object[] { this.playerNames[index], this.heroNames[index][0] }));
/* 474 */       this.soundPlayer.playA("horse");
/* 475 */       break;
/*     */     
/*     */ 
/*     */     case 302: 
/* 479 */       int index = Integer.parseInt(values[1]);
/* 480 */       this.hp_maxHps[index][0] = Integer.parseInt(values[2]);
/* 481 */       this.hp_maxHps[index][1] = Integer.parseInt(values[3]);
/*     */       
/* 483 */       this.txtHp[index].text = String.format("%d / %d", new Object[] { Integer.valueOf(this.hp_maxHps[index][0]), Integer.valueOf(this.hp_maxHps[index][1]) });
/*     */       
/* 485 */       System.out.println(String.format("【%s】 的血量為 %s/%s。", new Object[] { this.playerNames[index], values[2], values[3] }));
/*     */       
/* 487 */       idle(100);
/* 488 */       break;
/*     */     
/*     */     case 303: 
/* 491 */       int index = Integer.parseInt(values[1]);
/* 492 */       this.attackTimes[index] = Integer.parseInt(values[2]);
/* 493 */       System.out.println(String.format("【%s】 可攻擊  %s 次。", new Object[] { this.playerNames[index], values[2] }));
/* 494 */       break;
/*     */     
/*     */     case 304: 
/* 497 */       int index = Integer.parseInt(values[1]);
/* 498 */       this.drawCards[index] = Integer.parseInt(values[2]);
/* 499 */       System.out.println(String.format("【%s】 在抽牌階段可抽牌  %s 張。", new Object[] { this.playerNames[index], values[2] }));
/* 500 */       break;
/*     */     
/*     */     case 400: 
/* 503 */       int index = Integer.parseInt(values[1]);
/*     */       
/* 505 */       if (this.imgSpear.alpha > 0.0F)
/* 506 */         while (this.imgSpear.x < getWidth() / 2) {
/* 507 */           this.imgSpear.x += 10.0F;
/*     */           
/* 509 */           idle(1);
/*     */         }
/* 511 */       idle(200);
/* 512 */       this.imgSpear.alpha = 0.0F;
/*     */       
/* 514 */       if (this.imgShield.alpha > 0.0F)
/*     */       {
/* 516 */         while (this.imgShield.x < 400.0F) {
/* 517 */           this.imgShield.x += 10.0F;
/*     */           
/* 519 */           idle(1);
/*     */         }
/*     */       }
/* 522 */       idle(200);
/* 523 */       this.imgShield.alpha = 0.0F;
/*     */       
/* 525 */       System.out.println(String.format("【%s】受傷。", new Object[] { this.playerNames[index] }));
/*     */       
/* 527 */       this.soundPlayer.playA("blood");
/* 528 */       this.soundPlayer.playA("hurt" + (index + 1));
/* 529 */       aniHurt(index);
/*     */       
/* 531 */       break;
/*     */     
/*     */     case 401: 
/* 534 */       int index = Integer.parseInt(values[1]);
/*     */       
/* 536 */       this.imgSpearNormal.x = ((int)-this.imgSpearNormal.getW());
/* 537 */       this.imgSpearNormal.alpha = 0.0F;
/* 538 */       if (index == 0) {
/* 539 */         this.imgSpearNormal.posX = 8;
/* 540 */         this.imgSpearNormal.flipX = false;
/*     */       } else {
/* 542 */         this.imgSpearNormal.posX = 32;
/* 543 */         this.imgSpearNormal.flipX = true;
/*     */       }
/*     */       
/* 546 */       this.soundPlayer.playA("attack");
/* 547 */       while (this.imgSpearNormal.x < getWidth() / 4) {
/* 548 */         this.imgSpearNormal.x += 10.0F;
/* 549 */         this.imgSpearNormal.alpha = Math.min(this.imgSpearNormal.alpha + 0.1F, 1.0F);
/*     */         
/* 551 */         idle(1);
/*     */       }
/* 553 */       this.imgSpear = this.imgSpearNormal;
/* 554 */       System.out.println(String.format("【%s】作出攻擊。", new Object[] { this.playerNames[index] }));
/* 555 */       break;
/*     */     
/*     */     case 402: 
/* 558 */       int index = Integer.parseInt(values[1]);
/*     */       
/* 560 */       this.imgShieldNormal.x = ((int)-this.imgShieldNormal.getW());
/* 561 */       this.imgShieldNormal.alpha = 0.0F;
/* 562 */       if (index == 0) {
/* 563 */         this.imgShieldNormal.posX = 8;
/* 564 */         this.imgShieldNormal.flipX = false;
/*     */       } else {
/* 566 */         this.imgShieldNormal.posX = 32;
/* 567 */         this.imgShieldNormal.flipX = true;
/*     */       }
/* 569 */       while (this.imgShieldNormal.x < (getWidth() - this.imgShield.getW()) / 2.0D) {
/* 570 */         this.imgShieldNormal.x += 10.0F;
/* 571 */         this.imgShieldNormal.alpha = Math.min(this.imgShieldNormal.alpha + 0.1F, 1.0F);
/*     */         
/* 573 */         idle(1);
/*     */       }
/* 575 */       this.imgShield = this.imgShieldNormal;
/* 576 */       System.out.println(String.format("【%s】作出閃避。", new Object[] { this.playerNames[index] }));
/* 577 */       break;
/*     */     
/*     */     case 403: 
/* 580 */       int index = Integer.parseInt(values[1]);
/* 581 */       this.soundPlayer.playA("swallow");
/* 582 */       System.out.println(String.format("【%s】回復血量。", new Object[] { this.playerNames[index] }));
/* 583 */       break;
/*     */     
/*     */     case 500: 
/* 586 */       this.soundPlayer.playA("load");
/* 587 */       int index = Integer.parseInt(values[1]);
/* 588 */       Card card = Card.values()[Integer.parseInt(values[2])];
/* 589 */       ImageObject obj = new ImageObject((Image)this.images.get(card.name()), this);
/* 590 */       obj.tag = card;
/* 591 */       this.buffs[index].add(obj);
/* 592 */       aniAddCard(obj);
/* 593 */       obj.zoom = 0.4D;
/* 594 */       System.out.println(String.format("【%s】裝備【%s】。", new Object[] { this.playerNames[index], card.chiName }));
/*     */       
/* 596 */       idle(100);
/* 597 */       break;
/*     */     
/*     */     case 501: 
/* 600 */       int index = Integer.parseInt(values[1]);
/* 601 */       Card card = Card.values()[Integer.parseInt(values[2])];
/* 602 */       for (int i = 0; i < this.buffs[index].size(); i++) {
/* 603 */         ImageObject obj = (ImageObject)this.buffs[index].get(i);
/* 604 */         if (obj.tag == card) {
/* 605 */           this.soundPlayer.playA("unload");
/* 606 */           aniRemoveCard(obj);
/* 607 */           this.buffs[index].remove(i);
/* 608 */           System.out.println(String.format("【%s】除下【%s】。", new Object[] { this.playerNames[index], card.chiName }));
/*     */         }
/*     */       }
/*     */       
/* 612 */       idle(100);
/* 613 */       break;
/*     */     
/*     */     case 600: 
/* 616 */       int index = Integer.parseInt(values[1]);
/*     */       
/* 618 */       this.imgSpearCritical.x = this.imgSpearNormal.x;
/* 619 */       this.imgSpearCritical.y = this.imgSpearNormal.y;
/* 620 */       this.imgSpearCritical.alpha = 0.0F;
/* 621 */       this.imgSpearCritical.flipX = this.imgSpearNormal.flipX;
/* 622 */       this.imgSpearCritical.posX = this.imgSpearNormal.posX;
/*     */       
/* 624 */       while (this.imgSpearCritical.alpha < 1.0F) {
/* 625 */         this.imgSpearCritical.alpha += 0.1F;
/*     */         
/* 627 */         idle(10);
/*     */       }
/* 629 */       this.imgSpearNormal.alpha = 0.0F;
/* 630 */       this.imgSpear = this.imgSpearCritical;
/*     */       
/* 632 */       if (this.imgShieldNormal.alpha > 0.0F) {
/* 633 */         this.soundPlayer.playA("crash");
/*     */       }
/* 635 */       while (this.imgShieldNormal.alpha > 0.0F) {
/* 636 */         this.imgShieldNormal.alpha -= 0.1F;
/*     */         
/* 638 */         idle(10);
/*     */       }
/*     */       
/* 641 */       System.out.println(String.format("【%s】 使出《貫穿攻撃》。", new Object[] { this.playerNames[index] }));
/* 642 */       idle(500);
/* 643 */       break;
/*     */     
/*     */     case 601: 
/* 646 */       int index = Integer.parseInt(values[1]);
/*     */       
/* 648 */       this.imgShieldReflect.x = this.imgShieldNormal.x;
/* 649 */       this.imgShieldReflect.y = this.imgShieldNormal.y;
/* 650 */       this.imgShieldReflect.alpha = 0.0F;
/* 651 */       this.imgShieldReflect.flipX = this.imgShieldNormal.flipX;
/* 652 */       this.imgShieldReflect.posX = this.imgShieldNormal.posX;
/* 653 */       while (this.imgShieldReflect.alpha < 1.0F) {
/* 654 */         this.imgShieldReflect.alpha += 0.1F;
/*     */         
/* 656 */         idle(10);
/*     */       }
/* 658 */       this.imgShield = this.imgShieldReflect;
/* 659 */       this.imgShieldNormal.alpha = 0.0F;
/*     */       
/* 661 */       if (this.imgSpearNormal.alpha > 0.0F) {
/* 662 */         this.soundPlayer.playA("crash");
/*     */       }
/* 664 */       while (this.imgSpearNormal.alpha > 0.0F) {
/* 665 */         this.imgSpearNormal.alpha -= 0.1F;
/*     */         
/* 667 */         idle(10);
/*     */       }
/*     */       
/* 670 */       System.out.println(String.format("【%s】 使出《反撃》。", new Object[] { this.playerNames[index] }));
/* 671 */       idle(500);
/*     */       
/* 673 */       break;
/*     */     
/*     */     case 602: 
/* 676 */       this.soundPlayer.playA("reflect");
/* 677 */       while (this.imgSpear.alpha > 0.0F) {
/* 678 */         this.imgSpear.alpha -= 0.1F;
/* 679 */         this.imgShield.alpha -= 0.1F;
/*     */         
/* 681 */         idle(10);
/*     */       }
/* 683 */       break;
/*     */     
/*     */     case 700: 
/* 686 */       this.handCards[0].clear();
/* 687 */       this.handCards[1].clear();
/* 688 */       this.buffs[0].clear();
/* 689 */       this.buffs[1].clear();
/* 690 */       break;
/*     */     
/*     */     case 800: 
/* 693 */       this.lightningEffectObj.on();
/* 694 */       this.soundPlayer.playA("lightning");
/* 695 */       idle(100);
/* 696 */       this.soundPlayer.playA("hurt1");
/* 697 */       this.soundPlayer.playA("hurt2");
/* 698 */       System.out.println(String.format("打雷！相方受到%s的雷撃傷害。", new Object[] { values[1] }));
/* 699 */       break;
/*     */     
/*     */     case 888: 
/* 702 */       int index = Integer.parseInt(values[1]);
/* 703 */       System.out.println(String.format("〔%s〕勝出", new Object[] { this.playerNames[index] }));
/* 704 */       this.imgEnd.image = ((Image)this.images.get("End0"));
/* 705 */       this.txtEnd.text = this.playerNames[index];
/* 706 */       this.soundPlayer.playA("win");
/* 707 */       while (this.imgEnd.alpha < 1.0F) {
/* 708 */         this.imgEnd.alpha += 0.1F;
/* 709 */         this.imgEnd.zoom = this.imgEnd.alpha;
/* 710 */         idle(50);
/*     */       }
/*     */       
/* 713 */       break;
/*     */     
/*     */ 
/*     */     case 899: 
/* 717 */       this.imgEnd.image = ((Image)this.images.get("End1"));
/* 718 */       while (this.imgEnd.alpha < 1.0F) {
/* 719 */         this.imgEnd.alpha += 0.1F;
/* 720 */         this.imgEnd.zoom = this.imgEnd.alpha;
/* 721 */         idle(50);
/*     */       }
/* 723 */       System.out.println(String.format("和局", new Object[0]));
/* 724 */       break;
/*     */     case 999: 
/* 726 */       this.soundPlayer.pause("bg");
/* 727 */       this.soundPlayer.playA("win");
/* 728 */       break;
/*     */     case 0: 
/* 730 */       this.render = true;
/* 731 */       this.soundPlayer.playLoop("bg");
/* 732 */       System.out.println("動畫開始");
/* 733 */       break;
/*     */     case 1001: 
/* 735 */       int index = Integer.parseInt(values[1]);
/* 736 */       this.imgHeroes[index][0].image = ((Image)this.images.get("許褚2"));
/* 737 */       System.out.println(String.format("【%s】許褚強化。", new Object[] { this.playerNames[index] }));
/* 738 */       break;
/*     */     
/*     */     case 1000: 
/* 741 */       int index = Integer.parseInt(values[1]);
/* 742 */       this.imgHeroes[index][0].image = ((Image)this.images.get("許褚"));
/* 743 */       System.out.println(String.format("【%s】許褚回復正常。", new Object[] { this.playerNames[index] }));
/* 744 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void paint(Graphics g)
/*     */   {
/* 754 */     if (!this.render) {
/* 755 */       return;
/*     */     }
/* 757 */     Graphics2D g2 = (Graphics2D)g;
/* 758 */     g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 759 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */     
/*     */ 
/* 762 */     double ratioX = getWidth() / this.imgBg.image.getWidth(null);
/* 763 */     double ratioY = getHeight() / this.imgBg.image.getHeight(null);
/* 764 */     this.imgBg.zoom = Math.max(ratioX, ratioY);
/*     */     
/* 766 */     this.imgBg.draw(g2);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 771 */     int w = ((Image)this.images.get("Card")).getWidth(null);
/* 772 */     int x = getWidth() / 2 - (this.discardedCards.size() - 1) * 20 / 2;
/* 773 */     for (int i = 0; i < this.discardedCards.size(); i++) {
/* 774 */       this.imgDiscardedCard.image = ((Image)this.images.get(((Card)this.discardedCards.get(i)).name()));
/* 775 */       this.imgDiscardedCard.setPosition(x + 20 * i, 10 + 20 * (i % 2), new int[] { 4 });
/*     */       
/* 777 */       this.imgDiscardedCard.draw(g2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 782 */     Object[] objs = this.voList.toArray();
/* 783 */     Object[] arrayOfObject1; int j = (arrayOfObject1 = objs).length; for (int i = 0; i < j; i++) { Object obj = arrayOfObject1[i];
/* 784 */       ((VisualObject)obj).draw(g2);
/*     */     }
/*     */     
/* 787 */     for (int i = 0; i < 2; i++) {
/* 788 */       if (this.imgHeroes[i] != null) {
/* 789 */         for (int j = this.imgHeroes[i].length - 1; j >= 0; j--) {
/* 790 */           if (this.imgHeroes[i][j] != null) {
/* 791 */             this.imgHeroes[i][j].draw(g2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 796 */     int alignX = 8;
/* 797 */     int i = 0; int hp; int maxHp; int width1; for (int j = 1; i < 2; j = -1) {
/* 798 */       hp = this.hp_maxHps[i][0];
/* 799 */       maxHp = this.hp_maxHps[i][1];
/* 800 */       width1 = (int)(0.5D * hp);
/* 801 */       int width2 = (int)(0.5D * maxHp);
/* 802 */       x = 150 * j + (getWidth() - width1) * i;
/* 803 */       if (hp > maxHp / 2) {
/* 804 */         g2.setColor(Color.GREEN);
/* 805 */       } else if (hp > maxHp / 4) {
/* 806 */         g2.setColor(Color.YELLOW);
/*     */       } else {
/* 808 */         g2.setColor(Color.RED);
/*     */       }
/* 810 */       g2.fillRoundRect(x, (int)(this.txtHp[i].y - this.txtHp[i].h / 2.0D), width1, (int)this.txtHp[i].h, 20, 20);
/* 811 */       this.txtHp[i].x = ((int)(150.0D + 0.5D * width2));
/* 812 */       this.txtHp[i].w = width2;
/* 813 */       this.txtHp[i].draw(g2);
/*     */       
/* 815 */       for (int t = 0; t < this.attackTimes[i]; t++) {
/* 816 */         this.imgSword.setPosition((int)(45.0D + this.imgSword.getW() * t), 250.0F, new int[] { alignX });
/* 817 */         this.imgSword.draw(g2);
/*     */       }
/* 819 */       alignX = 32;i++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 824 */     x = 250;
/* 825 */     int y = 0;
/* 826 */     int gap = 50;
/* 827 */     alignX = 8;
/*     */     
/* 829 */     for (int i = 0; i < 2; i++) {
/* 830 */       objs = this.handCards[i].toArray();
/* 831 */       y = 220;
/* 832 */       maxHp = (width1 = objs).length; for (hp = 0; hp < maxHp; hp++) { Object o = width1[hp];
/* 833 */         VisualObject obj = (VisualObject)o;
/* 834 */         y += gap;
/* 835 */         obj.y = y;
/* 836 */         if ((this.visible[i] == 0) && (obj.x == x)) {
/* 837 */           this.imgCard.setPosition(obj.x, obj.y, new int[] { obj.posX, obj.posY });
/* 838 */           this.imgCard.alpha = obj.alpha;
/* 839 */           this.imgCard.zoom = obj.zoom;
/* 840 */           this.imgCard.draw(g2);
/*     */         } else {
/* 842 */           obj.draw(g2);
/*     */         } }
/* 844 */       alignX = 32;
/*     */     }
/*     */     
/*     */ 
/* 848 */     y = 100;
/*     */     
/* 850 */     for (int i = 0; i < this.buttons.size(); i++) {
/* 851 */       VisualObject obj = (VisualObject)this.buttons.get(i);
/* 852 */       obj.setPosition(0.0F, y, new int[] { 16 });
/* 853 */       obj.draw(g2);
/* 854 */       y = (int)(y + obj.getH() + 10.0D);
/*     */     }
/*     */     
/*     */ 
/* 858 */     y = 145;
/* 859 */     gap = 18;
/* 860 */     alignX = 8;
/* 861 */     for (int i = 0; i < 2; i++) {
/* 862 */       x = 180;
/* 863 */       objs = this.buffs[i].toArray();
/* 864 */       maxHp = (width1 = objs).length; for (hp = 0; hp < maxHp; hp++) { Object o = width1[hp];
/* 865 */         VisualObject obj = (VisualObject)o;
/* 866 */         obj.setPosition(x, y, new int[] { alignX });
/* 867 */         obj.draw(g2);
/* 868 */         x = (int)(x + (obj.getW() + gap));
/*     */       }
/* 870 */       alignX = 32;
/* 871 */       x = 20;
/*     */     }
/*     */     
/*     */ 
/* 875 */     this.hurtEffectObj.draw(g2);
/* 876 */     this.lightningEffectObj.draw(g2);
/*     */     
/* 878 */     if (this.imgEnd.alpha > 0.0F) {
/* 879 */       this.imgEnd.draw(g2);
/* 880 */       this.txtEnd.draw(g2);
/*     */     }
/*     */     
/* 883 */     g2.setColor(Color.GRAY);
/* 884 */     g2.drawRect(getWidth() - 20, 2, 18, 18);
/* 885 */     g2.drawLine(getWidth() - 20, 2, getWidth() - 2, 20);
/* 886 */     g2.drawLine(getWidth() - 20, 20, getWidth() - 2, 2);
/*     */     
/* 888 */     g2.setFont(this.font);
/* 889 */     g2.drawRect(getWidth() - 40, 2, 18, 18);
/* 890 */     g2.drawString("⏩", getWidth() - 35, 15);
/*     */     
/* 892 */     g2.drawRect(getWidth() - 60, 2, 18, 18);
/* 893 */     g2.drawString("🔊", getWidth() - 58, 15);
/*     */   }
/*     */   
/*     */   public void run()
/*     */   {
/*     */     for (;;) {
/* 899 */       repaint();
/*     */       try {
/* 901 */         Thread.sleep(1L);
/*     */       } catch (InterruptedException e) {
/* 903 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mute() {
/* 909 */     this.soundPlayer = this.soundPlayerDummy;
/* 910 */     this.soundPlayerNormal.stopAll();
/*     */   }
/*     */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\AnimationPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */