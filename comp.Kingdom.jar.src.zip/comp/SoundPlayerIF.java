package comp;

abstract interface SoundPlayerIF
{
  public abstract void playA(String paramString);
  
  public abstract void playLoop(String paramString);
  
  public abstract void pause(String paramString);
  
  public abstract void stopAll();
}


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\SoundPlayerIF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */