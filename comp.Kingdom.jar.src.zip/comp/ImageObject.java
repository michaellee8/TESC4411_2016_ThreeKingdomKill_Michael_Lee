/*     */ package comp;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ImageObject
/*     */   extends VisualObject
/*     */ {
/*  77 */   Image image = null;
/*     */   
/*     */   ImageObject(Image image, JComponent canvas) {
/*  80 */     super(canvas);
/*  81 */     this.image = image;
/*     */   }
/*     */   
/*     */   void draw(Graphics2D g2)
/*     */   {
/*  86 */     if (this.alpha < 0.0F) {
/*  87 */       return;
/*     */     }
/*  89 */     double w = getW();
/*  90 */     double h = getH();
/*     */     
/*  92 */     double xx = this.x - w / 2.0D;
/*  93 */     double yy = this.y - h / 2.0D;
/*     */     
/*  95 */     switch (this.posX) {
/*     */     case 32: 
/*  97 */       xx = this.canvas.getWidth() - w / 2.0D - this.x;
/*  98 */       break;
/*     */     case 16: 
/* 100 */       xx = (this.canvas.getWidth() - w) / 2.0D + this.x;
/*     */     }
/*     */     
/* 103 */     switch (this.posY) {
/*     */     case 4: 
/* 105 */       yy = this.canvas.getHeight() - h / 2.0D - this.y;
/* 106 */       break;
/*     */     case 2: 
/* 108 */       yy = (this.canvas.getHeight() - h) / 2.0D + this.y;
/*     */     }
/*     */     
/*     */     
/* 112 */     Composite comp = AlphaComposite.getInstance(3, Math.min(1.0F, this.alpha));
/* 113 */     g2.setComposite(comp);
/* 114 */     int ww = (int)w;
/* 115 */     int hh = (int)h;
/* 116 */     if (this.flipX) {
/* 117 */       ww = -ww;
/* 118 */       xx += w;
/*     */     }
/* 120 */     if (this.flipY) {
/* 121 */       hh = -hh;
/* 122 */       yy += h;
/*     */     }
/*     */     
/* 125 */     g2.drawImage(this.image, (int)xx, (int)yy, ww, hh, null);
/* 126 */     comp = AlphaComposite.getInstance(3, 1.0F);
/* 127 */     g2.setComposite(comp);
/*     */   }
/*     */   
/*     */   double getW()
/*     */   {
/* 132 */     return this.image.getWidth(null) * this.zoom;
/*     */   }
/*     */   
/*     */   double getH()
/*     */   {
/* 137 */     return this.image.getHeight(null) * this.zoom;
/*     */   }
/*     */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\ImageObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */