/*    */ package comp;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class HeroXuChu extends Hero {
/*  6 */   public final void join(int index) { GameMaster master = GameMaster.getInstance();
/*  7 */     GameMaster.Player player = master.players[index];
/*  8 */     player.attList.add(new Attributes("許褚", 400, 1, 2, 0, 0, Stage.Drawing));
/*  9 */     player.heroes.add(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final void spec()
/*    */   {
/* 16 */     GameMaster.getInstance().specXuChu();
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\HeroXuChu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */