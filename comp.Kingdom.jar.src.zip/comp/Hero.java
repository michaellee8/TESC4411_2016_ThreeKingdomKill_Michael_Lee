/*     */ package comp;
/*     */ 
/*     */ 
/*     */ public abstract class Hero
/*     */ {
/*     */   public abstract void join(int paramInt);
/*     */   
/*     */ 
/*     */   public abstract void drawing();
/*     */   
/*     */ 
/*     */   public abstract void myTurn();
/*     */   
/*     */ 
/*     */   public abstract void discarding();
/*     */   
/*     */ 
/*     */   public abstract void beingAttack();
/*     */   
/*     */ 
/*     */   public final void draw()
/*     */   {
/*  23 */     GameMaster.getInstance().draw();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void use(Card card)
/*     */   {
/*  34 */     GameMaster.getInstance().use(new Card[] { card });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void use(Card card, Card targetCard)
/*     */   {
/*  45 */     GameMaster.getInstance().use(new Card[] { card, targetCard });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void discard(Card card)
/*     */   {
/*  53 */     GameMaster.getInstance().discard(card);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Card[] getBuffList()
/*     */   {
/*  62 */     return GameMaster.getInstance().getBuffList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void deactivate(Card buff_card)
/*     */   {
/*  70 */     GameMaster.getInstance().deactivate(buff_card);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getHp()
/*     */   {
/*  79 */     return GameMaster.getInstance().getHp();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getMaxHp()
/*     */   {
/*  88 */     return GameMaster.getInstance().getMaxHp();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int countHandCards()
/*     */   {
/*  97 */     return GameMaster.getInstance().countHandCards();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int countHandCards(Card card)
/*     */   {
/* 108 */     return GameMaster.getInstance().countHandCards(card);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getAttackTimes()
/*     */   {
/* 117 */     return GameMaster.getInstance().getAttackTimes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isActive(Card card)
/*     */   {
/* 128 */     return GameMaster.getInstance().isActive(card);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int countBuffs()
/*     */   {
/* 137 */     return GameMaster.getInstance().countBuffs();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int countHeroes()
/*     */   {
/* 146 */     GameMaster master = GameMaster.getInstance();
/* 147 */     int index = master.stage == Stage.BeingAttack ? master.defenderIdx : master.attackerIdx;
/* 148 */     return GameMaster.getInstance().countHeroes(index);
/*     */   }
/*     */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\Hero.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */