/*    */ package comp;
/*    */ 
/*    */ final class Attributes {
/*    */   final int drawCards;
/*    */   final int maxHp;
/*    */   final int attackTimes;
/*    */   final String name;
/*    */   final int axe;
/*    */   final int shield;
/*    */   final Stage specStage;
/*    */   
/*    */   public Attributes(String name, int maxHp, int attackTimes, int drawCards, int axe, int shield, Stage specStage) {
/* 13 */     this.name = name;
/* 14 */     this.maxHp = maxHp;
/* 15 */     this.attackTimes = attackTimes;
/* 16 */     this.drawCards = drawCards;
/* 17 */     this.axe = axe;
/* 18 */     this.shield = shield;
/* 19 */     this.specStage = specStage;
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\Attributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */