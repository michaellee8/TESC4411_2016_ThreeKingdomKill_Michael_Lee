/*    */ package comp;
/*    */ 
/*    */ import java.awt.event.MouseEvent;
/*    */ import java.awt.event.MouseListener;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AniMouseListener
/*    */   implements MouseListener
/*    */ {
/*    */   public void mouseClicked(MouseEvent e)
/*    */   {
/* 27 */     AnimationPlayer player = GameMaster.getInstance().aniPlayer;
/* 28 */     int x = e.getX();
/* 29 */     int y = e.getY();
/* 30 */     if ((x > player.getWidth() - 20) && (y < 20)) {
/* 31 */       System.exit(0);
/*    */     }
/* 33 */     else if ((x > player.getWidth() - 40) && (y < 20)) {
/* 34 */       player.speed = ((player.speed + 1) % 4);
/* 35 */       System.out.println("Speed: " + player.speed);
/*    */     }
/* 37 */     else if ((x > player.getWidth() - 60) && (y < 20)) {
/* 38 */       System.err.println("Sound");
/* 39 */       if (player.soundPlayer == player.soundPlayerNormal) {
/* 40 */         player.mute();
/*    */       } else {
/* 42 */         player.soundPlayer = player.soundPlayerNormal;
/* 43 */         player.soundPlayer.playLoop("bg");
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void mouseEntered(MouseEvent e) {}
/*    */   
/*    */   public void mouseExited(MouseEvent e) {}
/*    */   
/*    */   public void mousePressed(MouseEvent e) {}
/*    */   
/*    */   public void mouseReleased(MouseEvent e) {}
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\AniMouseListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */