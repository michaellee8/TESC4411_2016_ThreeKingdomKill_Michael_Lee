/*     */ package comp;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Manual
/*     */   extends Hero
/*     */ {
/*  48 */   Map<String, Attributes> heroAttributes = new HashMap();
/*  49 */   Map<String, VisualObject> buttons = new HashMap();
/*  50 */   AnimationPlayer player = null;
/*  51 */   GameMaster master = null;
/*  52 */   String hero = null;
/*     */   
/*  54 */   static Object stuff = new Object();
/*  55 */   static Object action = null;
/*  56 */   MyListener listener = new MyListener();
/*  57 */   Card[] actionCards = { Card.Attack, Card.Defense, Card.Heal };
/*  58 */   Card[] funcCards = { Card.Agility, Card.Axe, Card.Grab, Card.Repeal, Card.RepealX, Card.Shield, Card.Vitality };
/*     */   
/*     */   private void waitForSelection() {
/*  61 */     System.out.println("Waiting for player input...");
/*     */     
/*  63 */     synchronized (GameMaster.getInstance().thread) {
/*     */       try {
/*  65 */         GameMaster.getInstance().thread.wait();
/*     */       } catch (InterruptedException e) {
/*  67 */         e.printStackTrace();
/*     */       }
/*     */     }
/*  70 */     this.player.buttons.clear();
/*  71 */     this.player.repaint();
/*     */   }
/*     */   
/*     */   public Manual(String hero) {
/*  75 */     this.heroAttributes.put("HeroGanNing", new Attributes("甘寧", 400, 1, 2, 0, 0, Stage.Action));
/*  76 */     this.heroAttributes.put("HeroHuangGai", new Attributes("黄蓋", 400, 1, 2, 0, 0, Stage.Action));
/*  77 */     this.heroAttributes.put("HeroMaChao", new Attributes("馬超", 400, 1, 2, 20, 0, null));
/*  78 */     this.heroAttributes.put("HeroXiaHouDun", new Attributes("夏侯惇", 400, 1, 2, 0, 20, null));
/*  79 */     this.heroAttributes.put("HeroXuChu", new Attributes("許褚", 400, 1, 2, 0, 0, Stage.Drawing));
/*  80 */     this.heroAttributes.put("HeroZhangFei", new Attributes("張飛", 400, 2, 2, 0, 0, null));
/*  81 */     this.heroAttributes.put("HeroZhangLiao", new Attributes("張遼", 400, 1, 2, 0, 0, Stage.Drawing));
/*  82 */     this.heroAttributes.put("HeroZhaoYun", new Attributes("趙雲", 400, 1, 2, 0, 0, null));
/*  83 */     this.heroAttributes.put("HeroZhouYu", new Attributes("周瑜", 300, 1, 3, 0, 0, null));
/*     */     
/*  85 */     this.hero = hero;
/*  86 */     this.master = GameMaster.getInstance();
/*  87 */     this.player = this.master.aniPlayer;
/*  88 */     VisualObject obj = null;
/*     */     
/*  90 */     for (int i = 0; i < Action.values().length; i++) {
/*  91 */       obj = new TextObject(Action.values()[i].chiName, this.player.fontB, this.player)
/*     */       {
/*     */         void onClick() {
/*  94 */           Manual.action = this.tag;
/*     */         }
/*  96 */       };
/*  97 */       obj.tag = Action.values()[i];
/*  98 */       this.buttons.put("Action_" + Action.values()[i].name(), obj);
/*     */     }
/*     */     
/* 101 */     for (int i = 0; i < this.actionCards.length; i++) {
/* 102 */       obj = new ImageObject((Image)this.player.images.get(this.actionCards[i].name()), this.player)
/*     */       {
/*     */         void onClick() {
/* 105 */           Manual.action = this.tag;
/*     */         }
/* 107 */       };
/* 108 */       obj.tag = this.actionCards[i];
/* 109 */       obj.zoom = 0.6D;
/* 110 */       this.buttons.put(this.actionCards[i].name(), obj);
/*     */     }
/*     */     
/* 113 */     for (int i = 0; i < this.funcCards.length; i++) {
/* 114 */       obj = new ImageObject((Image)this.player.images.get(this.funcCards[i].name()), this.player)
/*     */       {
/*     */         void onClick() {
/* 117 */           Manual.action = this.tag;
/*     */         }
/* 119 */       };
/* 120 */       obj.tag = this.funcCards[i];
/* 121 */       obj.zoom = 0.6D;
/* 122 */       this.buttons.put(this.funcCards[i].name(), obj);
/*     */     }
/*     */     
/* 125 */     obj = new ImageObject((Image)this.player.images.get("Card"), this.player)
/*     */     {
/*     */       void onClick() {
/* 128 */         Manual.action = this.tag;
/*     */       }
/* 130 */     };
/* 131 */     obj.tag = null;
/* 132 */     obj.zoom = 0.6D;
/* 133 */     this.buttons.put("HandCard", obj);
/*     */     
/* 135 */     this.player.removeMouseListener(this.player.getMouseListeners()[0]);
/* 136 */     this.player.addMouseListener(this.listener);
/*     */   }
/*     */   
/*     */ 
/*     */   public void drawing()
/*     */   {
/* 142 */     if (((Attributes)this.heroAttributes.get(this.hero)).specStage == Stage.Drawing) {
/* 143 */       this.player.buttons.add((VisualObject)this.buttons.get("Action_Draw"));
/* 144 */       this.player.buttons.add((VisualObject)this.buttons.get("Action_Spec"));
/*     */       
/* 146 */       waitForSelection();
/*     */       
/* 148 */       if ((Action)action == Action.Draw) {
/* 149 */         this.master.draw();
/*     */       } else { String str;
/* 151 */         switch ((str = this.hero).hashCode()) {case 1345657:  if (str.equals("HeroXuChu")) break;  case 2011830653:  if ((goto 194) || (!str.equals("HeroZhangLiao")))
/*     */             return;
/* 153 */           this.master.specZhangLiao();
/* 154 */           return;
/*     */           
/* 156 */           this.master.specXuChu();
/* 157 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 163 */       this.master.draw();
/*     */     }
/*     */   }
/*     */   
/*     */   public void myTurn()
/*     */   {
/* 169 */     boolean running = true;
/* 170 */     while (running)
/*     */     {
/* 172 */       if (this.master.countBuffs() + 
/* 173 */         this.master.countOppBuffs() + 
/* 174 */         this.master.countHandCards() + 
/* 175 */         this.master.countOppHandCards() + 
/* 176 */         this.master.countNonReleasedCards() + 
/* 177 */         this.master.countDiscardedCards() != 
/* 178 */         this.master.numOfCards) {
/* 179 */         System.err.println("牌數不對!");
/* 180 */         System.exit(-1);
/*     */       }
/*     */       
/* 183 */       if ((this.master.getAttackTimes() > 0) && ((this.master.countHandCards(Card.Attack) > 0) || ((this.hero.equals("HeroZhaoYun")) && (this.master.countHandCards(Card.Defense) > 0)))) {
/* 184 */         this.player.buttons.add((VisualObject)this.buttons.get("Action_Attack"));
/*     */       }
/* 186 */       if (this.master.countHandCards(Card.Heal) > 0)
/* 187 */         this.player.buttons.add((VisualObject)this.buttons.get("Action_Heal"));
/* 188 */       if (this.master.countFuncCards() > 0)
/* 189 */         this.player.buttons.add((VisualObject)this.buttons.get("Action_Func"));
/* 190 */       if (this.master.countBuffs() > 0) {
/* 191 */         this.player.buttons.add((VisualObject)this.buttons.get("Action_Debuff"));
/*     */       }
/* 193 */       if (((Attributes)this.heroAttributes.get(this.hero)).specStage == Stage.Action) {
/* 194 */         this.player.buttons.add((VisualObject)this.buttons.get("Action_Spec"));
/*     */       }
/* 196 */       if (this.player.buttons.size() > 0) {
/* 197 */         this.player.buttons.add((VisualObject)this.buttons.get("Action_Noting"));
/*     */         
/* 199 */         waitForSelection();
/*     */         
/* 201 */         switch ((Action)action) {
/*     */         case Cancel: 
/* 203 */           this.master.use(new Card[] { Card.Attack });
/* 204 */           break;
/*     */         case Defense: 
/* 206 */           this.master.use(new Card[] { Card.Heal });
/* 207 */           break;
/*     */         case Draw: 
/* 209 */           func();
/* 210 */           break;
/*     */         case Func: 
/* 212 */           debuff();
/* 213 */           break;
/*     */         case Heal:  String str;
/* 215 */           switch ((str = this.hero).hashCode()) {case -1443138514:  if (str.equals("HeroGanNing")) break;  case 182670364:  if ((goto 533) && (str.equals("HeroHuangGai")))
/*     */             {
/* 217 */               this.master.specHuangeGai();
/* 218 */               continue;
/*     */               
/* 220 */               specGanNing(); }
/* 221 */             break;
/*     */           }
/* 223 */           System.err.println(this.hero);
/*     */           
/*     */ 
/*     */ 
/* 227 */           break;
/*     */         case Debuff: default: 
/* 229 */           running = false;
/*     */           
/*     */ 
/*     */ 
/* 233 */           break; }
/* 234 */       } else { running = false;
/*     */       }
/*     */     } }
/*     */   
/*     */   void specGanNing() { Card[] arrayOfCard;
/* 239 */     int j = (arrayOfCard = this.funcCards).length; for (int i = 0; i < j; i++) { Card card = arrayOfCard[i];
/* 240 */       if ((card.type == 1) && (this.master.countHandCards(card) > 0)) {
/* 241 */         this.player.buttons.add((VisualObject)this.buttons.get(card.name()));
/*     */       }
/*     */     }
/*     */     
/* 245 */     if (this.master.countHandCards(Card.Heal) > 0) {
/* 246 */       this.player.buttons.add((VisualObject)this.buttons.get(Card.Heal.name()));
/*     */     }
/* 248 */     this.player.buttons.add((VisualObject)this.buttons.get("Action_Cancel"));
/*     */     
/* 250 */     waitForSelection();
/* 251 */     if (action.getClass().getName().equals("comp.Card")) {
/* 252 */       Card cc = (Card)action;
/* 253 */       this.master.specGanNing(cc);
/*     */     }
/*     */   }
/*     */   
/*     */   void func() { Card[] arrayOfCard1;
/* 258 */     int j = (arrayOfCard1 = this.funcCards).length; for (int i = 0; i < j; i++) { Card card = arrayOfCard1[i];
/* 259 */       if (this.master.countHandCards(card) > 0) {
/* 260 */         this.player.buttons.add((VisualObject)this.buttons.get(card.name()));
/*     */       }
/*     */     }
/* 263 */     this.player.buttons.add((VisualObject)this.buttons.get("Action_Cancel"));
/*     */     
/* 265 */     waitForSelection();
/*     */     
/* 267 */     if (action.getClass().getName().equals("comp.Card")) {
/* 268 */       Card cc = (Card)action;
/* 269 */       if (cc.type == 2) { Card[] arrayOfCard2;
/* 270 */         int k = (arrayOfCard2 = this.master.getOppBuffList()).length; for (j = 0; j < k; j++) { Card buff = arrayOfCard2[j];
/* 271 */           this.player.buttons.add((VisualObject)this.buttons.get(buff.name()));
/*     */         }
/* 273 */         if (this.master.countOppHandCards() > 0) {
/* 274 */           this.player.buttons.add((VisualObject)this.buttons.get("HandCard"));
/*     */         }
/* 276 */         if (this.player.buttons.size() > 0) {
/* 277 */           this.player.buttons.add((VisualObject)this.buttons.get("Action_Cancel"));
/*     */           
/* 279 */           waitForSelection();
/* 280 */           if (action == null) {
/* 281 */             use(cc);
/* 282 */           } else if (action.getClass().getName().equals("comp.Card")) {
/* 283 */             use(cc, (Card)action);
/*     */           }
/*     */         } else {
/* 286 */           use(cc);
/*     */         }
/* 288 */       } else { use(cc);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 293 */   void debuff() { Card[] buffs = getBuffList();
/* 294 */     Card[] arrayOfCard1; int j = (arrayOfCard1 = buffs).length; for (int i = 0; i < j; i++) { Card card = arrayOfCard1[i];
/* 295 */       this.player.buttons.add((VisualObject)this.buttons.get(card.name()));
/*     */     }
/* 297 */     this.player.buttons.add((VisualObject)this.buttons.get("Action_Cancel"));
/* 298 */     waitForSelection();
/*     */     
/* 300 */     if (action.getClass().getName().equals("comp.Card")) {
/* 301 */       deactivate((Card)action);
/*     */     }
/*     */   }
/*     */   
/*     */   public void discarding() {
/* 306 */     while (this.master.countHandCards() > 0) { Card[] arrayOfCard;
/* 307 */       int j = (arrayOfCard = this.actionCards).length; for (int i = 0; i < j; i++) { Card card = arrayOfCard[i];
/* 308 */         if (this.master.countHandCards(card) > 0) {
/* 309 */           this.player.buttons.add((VisualObject)this.buttons.get(card.name()));
/*     */         }
/*     */       }
/* 312 */       j = (arrayOfCard = this.funcCards).length; for (i = 0; i < j; i++) { Card card = arrayOfCard[i];
/* 313 */         if (this.master.countHandCards(card) > 0) {
/* 314 */           this.player.buttons.add((VisualObject)this.buttons.get(card.name()));
/*     */         }
/*     */       }
/* 317 */       this.player.buttons.add((VisualObject)this.buttons.get("Action_Noting"));
/*     */       
/* 319 */       waitForSelection();
/*     */       
/* 321 */       if (!action.getClass().getName().equals("comp.Card")) break;
/* 322 */       discard((Card)action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void beingAttack()
/*     */   {
/* 330 */     if ((this.master.countHandCards(Card.Defense) > 0) || ((this.hero.equals("HeroZhaoYun")) && (this.master.countHandCards(Card.Attack) > 0)))
/*     */     {
/* 332 */       this.player.buttons.add((VisualObject)this.buttons.get("Action_Defense"));
/* 333 */       this.player.buttons.add((VisualObject)this.buttons.get("Action_Noting"));
/* 334 */       waitForSelection();
/* 335 */       if ((Action)action == Action.Defense) {
/* 336 */         this.master.use(new Card[] { Card.Defense });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void join(int index) {
/* 342 */     this.master.players[index].attList.add((Attributes)this.heroAttributes.get(this.hero));
/* 343 */     this.master.players[index].heroes.add(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\Manual.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */