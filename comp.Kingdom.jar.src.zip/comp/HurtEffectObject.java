/*     */ package comp;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Composite;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Paint;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HurtEffectObject
/*     */   extends VisualObject
/*     */ {
/*     */   HurtEffectObject(JComponent canvas)
/*     */   {
/* 248 */     super(canvas);
/*     */   }
/*     */   
/*     */   double getW()
/*     */   {
/* 253 */     return this.canvas.getWidth();
/*     */   }
/*     */   
/*     */   double getH()
/*     */   {
/* 258 */     return this.canvas.getHeight();
/*     */   }
/*     */   
/*     */   void draw(Graphics2D g2)
/*     */   {
/* 263 */     if (this.alpha < 0.0F) {
/* 264 */       return;
/*     */     }
/* 266 */     Color sC = Color.RED;
/* 267 */     Color eC = new Color(0, 0, 0, 0);
/* 268 */     Paint op = g2.getPaint();
/* 269 */     Composite comp = AlphaComposite.getInstance(3, Math.min(1.0F, this.alpha));
/* 270 */     g2.setComposite(comp);
/* 271 */     GradientPaint gp = null;
/*     */     
/* 273 */     if (this.posX == 32) {
/* 274 */       gp = new GradientPaint(this.canvas.getWidth(), 0.0F, sC, 0.0F, this.canvas.getHeight(), eC);
/*     */     } else {
/* 276 */       gp = new GradientPaint(0.0F, 0.0F, sC, this.canvas.getWidth(), this.canvas.getHeight(), eC);
/*     */     }
/* 278 */     g2.setPaint(gp);
/* 279 */     g2.fillRect(0, 0, this.canvas.getWidth(), this.canvas.getHeight());
/* 280 */     g2.setPaint(op);
/* 281 */     comp = AlphaComposite.getInstance(3, Math.min(1, Math.max(0, 1)));
/* 282 */     g2.setComposite(comp);
/*     */   }
/*     */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\HurtEffectObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */