/*     */ package comp;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Composite;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import java.awt.geom.RoundRectangle2D.Double;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TextObject
/*     */   extends VisualObject
/*     */ {
/*     */   static enum Shape
/*     */   {
/* 143 */     RoundRect,  Rect,  Ellipse;
/*     */   }
/*     */   
/* 146 */   Shape shape = null;
/* 147 */   Color fillColor = null;
/* 148 */   Color strokeColor = null;
/* 149 */   Color textColor = null;
/* 150 */   float shapeAlpha = 0.4F;
/*     */   double w;
/*     */   double h;
/*     */   Font font;
/*     */   String text;
/*     */   
/* 156 */   TextObject(String text, Font font, JComponent canvas) { this(text, font, Color.WHITE, 0.0F, 0.0F, Color.BLACK, Color.WHITE, canvas); }
/*     */   
/*     */ 
/*     */   TextObject(String text, Font font, Color textColor, float width, float height, Color fillColor, Color strokeColor, JComponent canvas)
/*     */   {
/* 161 */     super(canvas);
/* 162 */     this.fillColor = fillColor;
/* 163 */     this.strokeColor = strokeColor;
/* 164 */     this.textColor = textColor;
/* 165 */     this.w = width;
/* 166 */     this.h = height;
/* 167 */     this.font = font;
/* 168 */     this.text = text;
/*     */   }
/*     */   
/*     */ 
/*     */   void draw(Graphics2D g2)
/*     */   {
/* 174 */     if (this.alpha < 0.0F) {
/* 175 */       return;
/*     */     }
/* 177 */     g2.setFont(this.font);
/* 178 */     int tW = g2.getFontMetrics(this.font).stringWidth(this.text);
/* 179 */     int tH = g2.getFontMetrics(this.font).getHeight();
/*     */     
/* 181 */     if (this.w < tW)
/* 182 */       this.w = (tW + 30);
/* 183 */     if (this.h < tH) {
/* 184 */       this.h = (tH + 10);
/*     */     }
/* 186 */     double xx = this.x - this.w / 2.0D;
/* 187 */     double yy = this.y - this.h / 2.0D;
/*     */     
/* 189 */     switch (this.posX) {
/*     */     case 32: 
/* 191 */       xx = this.canvas.getWidth() - this.w / 2.0D - this.x;
/* 192 */       break;
/*     */     case 16: 
/* 194 */       xx = this.canvas.getWidth() / 2 + xx;
/*     */     }
/*     */     
/* 197 */     switch (this.posY) {
/*     */     case 4: 
/* 199 */       yy = this.canvas.getHeight() - this.h / 2.0D - this.y;
/* 200 */       break;
/*     */     case 2: 
/* 202 */       yy = this.canvas.getHeight() / 2 + yy;
/*     */     }
/*     */     
/*     */     
/* 206 */     RoundRectangle2D rect = new RoundRectangle2D.Double(xx, yy, this.w, this.h, 20.0D, 20.0D);
/*     */     
/* 208 */     if (this.fillColor != null) {
/* 209 */       Composite comp = AlphaComposite.getInstance(3, Math.min(1.0F, Math.max(0.0F, this.shapeAlpha)));
/* 210 */       g2.setComposite(comp);
/* 211 */       g2.setColor(this.fillColor);
/* 212 */       g2.fill(rect);
/* 213 */       comp = AlphaComposite.getInstance(3, 1.0F);
/* 214 */       g2.setComposite(comp);
/*     */     }
/*     */     
/* 217 */     if (this.strokeColor != null) {
/* 218 */       Stroke oriStroke = g2.getStroke();
/* 219 */       g2.setColor(this.strokeColor);
/* 220 */       g2.setStroke(new BasicStroke(5.0F));
/* 221 */       g2.draw(rect);
/* 222 */       g2.setStroke(oriStroke);
/*     */     }
/*     */     
/* 225 */     g2.setColor(this.textColor);
/* 226 */     Composite comp = AlphaComposite.getInstance(3, Math.min(1.0F, Math.max(0.0F, this.alpha)));
/* 227 */     g2.setComposite(comp);
/* 228 */     g2.drawString(this.text, (int)(xx + (this.w - tW) / 2.0D), (int)(yy + tH));
/* 229 */     comp = AlphaComposite.getInstance(3, 1.0F);
/* 230 */     g2.setComposite(comp);
/*     */   }
/*     */   
/*     */   double getW()
/*     */   {
/* 235 */     return this.w;
/*     */   }
/*     */   
/*     */   double getH()
/*     */   {
/* 240 */     return this.h;
/*     */   }
/*     */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\TextObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */