/*      */ package comp;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class GameMaster implements Runnable
/*      */ {
/*      */   static final int render = 0;
/*      */   static final int cards = 100;
/*      */   static final int discardCard = 101;
/*      */   static final int addCard = 102;
/*      */   static final int removeCard = 103;
/*      */   static final int useCard = 104;
/*      */   static final int errorMsg = 200;
/*      */   static final int roundNum = 201;
/*      */   static final int setAttacker = 202;
/*      */   static final int playerName = 203;
/*      */   static final int name = 205;
/*      */   static final int hp = 302;
/*      */   static final int attackTimes = 303;
/*      */   static final int drawCards = 304;
/*      */   static final int hurt = 400;
/*      */   
/*      */   private static class Output
/*      */   {
/*   28 */     private static PrintStream[] streamList = null;
/*   29 */     private static AnimationPlayer player = null;
/*      */     
/*      */     static void set(AnimationPlayer aniPlayer, PrintStream... streams) {
/*   32 */       player = aniPlayer;
/*   33 */       streamList = new PrintStream[streams.length];
/*   34 */       for (int i = 0; i < streams.length; i++)
/*   35 */         streamList[i] = streams[i];
/*      */     }
/*      */     
/*      */     static void write(String format, Object... objects) { PrintStream[] arrayOfPrintStream;
/*   39 */       int j = (arrayOfPrintStream = streamList).length; for (int i = 0; i < j; i++) { PrintStream ps = arrayOfPrintStream[i];
/*   40 */         ps.println(String.format(format, objects));
/*      */       }
/*   42 */       player.animate(String.format(format, objects)); } }
/*      */   
/*      */   static final int attack = 401;
/*      */   static final int defense = 402;
/*      */   static final int heal = 403; static final int buff = 500; static final int debuff = 501; static final int axe = 600; static final int shield = 601;
/*   47 */   class Player { List<Card> handCards = new ArrayList();
/*   48 */     Player() {} List<Hero> heroes = new ArrayList();
/*   49 */     List<Attributes> attList = new ArrayList();
/*   50 */     List<Card> buffs = new ArrayList();
/*   51 */     int hp; int maxHp; int attackTimes; int _attackTimes; int drawCards; int axe; int shield; int power = 1;
/*      */     String name;
/*   53 */     String heroName; int heroIdx = -1;
/*   54 */     boolean canDrawCards = true;
/*   55 */     boolean canSpec = true;
/*      */     
/*      */     void drawing() {
/*   58 */       ((Hero)this.heroes.get(this.heroIdx)).drawing(); }
/*      */     
/*      */     void discard()
/*      */     {
/*   62 */       ((Hero)this.heroes.get(this.heroIdx)).discarding();
/*      */     }
/*      */     
/*      */     void action() {
/*   66 */       ((Hero)this.heroes.get(this.heroIdx)).myTurn();
/*      */     }
/*      */     
/*      */     int loadHero() {
/*   70 */       this.heroIdx += 1;
/*   71 */       if (this.heroes.size() > this.heroIdx) {
/*   72 */         Attributes att = (Attributes)this.attList.get(this.heroIdx);
/*   73 */         this.heroName = att.name;
/*   74 */         this.hp = (this.maxHp = att.maxHp);
/*   75 */         this._attackTimes = (this.attackTimes = att.attackTimes);
/*   76 */         this.drawCards = att.drawCards;
/*   77 */         this.axe = att.axe;
/*   78 */         this.shield = att.shield;
/*      */       }
/*      */       else {
/*   81 */         this.heroIdx = -1;
/*   82 */         this.heroName = null;
/*   83 */         this.hp = (this.maxHp = this.attackTimes = this._attackTimes = 0);
/*      */       }
/*   85 */       return this.heroIdx;
/*      */     }
/*      */     
/*      */ 
/*   89 */     void beingAttack() { ((Hero)this.heroes.get(this.heroIdx)).beingAttack(); } }
/*      */   
/*      */   static final int cancelOut = 602;
/*      */   static final int xuChuNormal = 1000;
/*   93 */   static final int xuChuPowerUp = 1001; static final int clearAll = 700; static final int lightning = 800; static final int winner = 888; static final int drawGame = 899; static final int end = 999; private static GameMaster instance = null;
/*   94 */   private boolean running = false;
/*   95 */   private boolean settingCommitted = false;
/*      */   
/*      */   Stage stage;
/*   98 */   private List<Card> discardedCards = null;
/*   99 */   private List<Card> cardStore = null;
/*  100 */   private int[] cardCount = { 15, 15, 6, 3, 3, 3, 3, 3 };
/*  101 */   public int numOfCards = 0;
/*  102 */   Player[] players = null;
/*      */   int attackerIdx;
/*      */   int defenderIdx;
/*  105 */   private boolean defenseOn = false;
/*  106 */   private int[] rNums = new int[100];
/*  107 */   private int rN = 0;
/*      */   
/*  109 */   Thread thread = null;
/*  110 */   private int lightningRound = 20;
/*      */   
/*  112 */   AnimationPlayer aniPlayer = null;
/*      */   
/*      */   private GameMaster()
/*      */   {
/*  116 */     for (int i = 1; i <= 100; i++) {
/*  117 */       int p = (int)(Math.random() * 100.0D);
/*  118 */       while (this.rNums[p] != 0)
/*  119 */         p = (p + 1) % 100;
/*  120 */       this.rNums[p] = i;
/*      */     }
/*      */     try
/*      */     {
/*  124 */       this.aniPlayer = new AnimationPlayer();
/*  125 */       this.aniPlayer.setSize(1024, 800);
/*  126 */       Output.set(this.aniPlayer, new PrintStream[] { new PrintStream(new java.io.FileOutputStream("kingdom.script")) });
/*      */     }
/*      */     catch (IOException e) {
/*  129 */       e.printStackTrace();
/*  130 */       System.exit(-1);
/*      */     }
/*      */     
/*  133 */     this.discardedCards = new ArrayList();
/*      */     
/*  135 */     this.cardStore = new ArrayList();
/*  136 */     for (int t = 0; t < this.cardCount.length; t++) {
/*  137 */       for (int c = 0; c < this.cardCount[t]; c++) {
/*  138 */         this.cardStore.add(Card.values()[t]);
/*      */       }
/*      */     }
/*  141 */     shuffle(5);
/*  142 */     this.numOfCards = this.cardStore.size();
/*      */     
/*  144 */     this.players = new Player[] { new Player(), new Player() };
/*  145 */     this.attackerIdx = ((int)(Math.random() * 2.0D));
/*  146 */     this.defenderIdx = ((this.attackerIdx + 1) % 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static GameMaster getInstance()
/*      */   {
/*  155 */     if (instance == null) {
/*  156 */       instance = new GameMaster();
/*      */     }
/*  158 */     return instance;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void start()
/*      */   {
/*  165 */     if (this.thread != null) {
/*  166 */       System.err.println("Invalid operation!");
/*  167 */       System.exit(-1);
/*      */     }
/*  169 */     this.thread = new Thread(this);
/*  170 */     this.thread.start();
/*  171 */     new Thread(this.aniPlayer).start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVisible(int index, boolean on)
/*      */   {
/*  183 */     this.aniPlayer.visible[index] = on;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLightning(int round)
/*      */   {
/*  192 */     this.lightningRound = round;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void run()
/*      */   {
/*  200 */     if (this.settingCommitted) {
/*  201 */       System.err.println("Invalid operation!");
/*  202 */       System.exit(-1);
/*      */     }
/*  204 */     this.settingCommitted = true;
/*  205 */     this.running = true;
/*      */     
/*  207 */     Output.write("%d|%d|%s", new Object[] { Integer.valueOf(203), Integer.valueOf(0), this.players[0].name });
/*  208 */     Output.write("%d|%d|%s", new Object[] { Integer.valueOf(203), Integer.valueOf(1), this.players[1].name });
/*      */     
/*  210 */     Output.write("//loading", new Object[0]);
/*  211 */     Output.write("0", new Object[0]);
/*      */     
/*  213 */     for (int i = 0; i < 2; i++) {
/*  214 */       Player player = this.players[i];
/*  215 */       if (player.loadHero() < 0) {
/*  216 */         System.err.println("Fail to load hero");
/*  217 */         System.exit(-1);
/*      */       }
/*      */       
/*  220 */       String heroNames = "";
/*  221 */       for (int c = 0; c < countHeroes(i); c++) {
/*  222 */         heroNames = heroNames + "|" + ((Attributes)player.attList.get(player.heroIdx + c)).name;
/*      */       }
/*  224 */       Output.write("%d|%d%s", new Object[] { Integer.valueOf(205), Integer.valueOf(i), heroNames });
/*  225 */       Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(i), Integer.valueOf(player.hp), Integer.valueOf(player.maxHp) });
/*  226 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(303), Integer.valueOf(i), Integer.valueOf(player.attackTimes) });
/*  227 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(304), Integer.valueOf(i), Integer.valueOf(player.drawCards) });
/*      */     }
/*      */     
/*      */ 
/*  231 */     Output.write("//game loop", new Object[0]);
/*      */     
/*  233 */     int round = 1;
/*  234 */     while (this.running)
/*      */     {
/*      */ 
/*  237 */       Output.write("//================================", new Object[0]);
/*  238 */       Output.write("%d|%d", new Object[] { Integer.valueOf(201), Integer.valueOf(round) });
/*      */       
/*  240 */       Output.write("%d|%d", new Object[] { Integer.valueOf(202), Integer.valueOf(this.attackerIdx) });
/*      */       
/*  242 */       Player attacker = this.players[this.attackerIdx];
/*  243 */       Player defender = this.players[this.defenderIdx];
/*      */       
/*  245 */       if (round == 1) {
/*  246 */         _draw(4, this.attackerIdx);
/*  247 */         _draw(4, this.defenderIdx);
/*      */       }
/*      */       
/*  250 */       attacker.attackTimes = attacker._attackTimes;
/*  251 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(303), Integer.valueOf(this.attackerIdx), Integer.valueOf(attacker.attackTimes) });
/*      */       
/*  253 */       if ((attacker.heroName.equals("許褚")) && (attacker.power > 1)) {
/*  254 */         Output.write("%d|%d", new Object[] { Integer.valueOf(1000), Integer.valueOf(this.attackerIdx) });
/*      */       }
/*  256 */       attacker.power = 1;
/*  257 */       attacker.canDrawCards = true;
/*  258 */       attacker.canSpec = true;
/*      */       
/*  260 */       if (round >= this.lightningRound) {
/*  261 */         int power = 5 * (1 + (round - this.lightningRound));
/*  262 */         attacker.hp = Math.max(0, attacker.hp - power);
/*  263 */         defender.hp = Math.max(0, defender.hp - power);
/*  264 */         Output.write("%d|%d", new Object[] { Integer.valueOf(800), Integer.valueOf(power) });
/*  265 */         Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(this.attackerIdx), Integer.valueOf(attacker.hp), Integer.valueOf(attacker.maxHp) });
/*  266 */         Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(this.defenderIdx), Integer.valueOf(defender.hp), Integer.valueOf(defender.maxHp) });
/*      */       }
/*      */       
/*  269 */       this.stage = Stage.Drawing;
/*  270 */       attacker.drawing();
/*      */       
/*  272 */       this.stage = Stage.Action;
/*      */       
/*  274 */       attacker.action();
/*      */       
/*  276 */       for (int i = 0; i < attacker.handCards.size(); i++)
/*      */       {
/*  278 */         if (attacker.handCards.get(i) == Card.RepealX) {
/*  279 */           attacker.handCards.remove(i);
/*  280 */           Card card = (Card)this.exchangedCards.remove(0);
/*  281 */           attacker.handCards.add(card);
/*  282 */           Output.write("%d|%d|%d", new Object[] { Integer.valueOf(103), Integer.valueOf(this.attackerIdx), Integer.valueOf(Card.RepealX.id) });
/*  283 */           Output.write("%d|%d|%d", new Object[] { Integer.valueOf(102), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*      */         }
/*      */       }
/*      */       
/*  287 */       this.stage = Stage.Discarding;
/*      */       
/*  289 */       attacker.discard();
/*  290 */       autoDiscard();
/*      */       
/*  292 */       attacker.attackTimes = 0;
/*  293 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(303), Integer.valueOf(this.attackerIdx), Integer.valueOf(attacker.attackTimes) });
/*      */       
/*  295 */       if ((this.players[0].hp == 0) || (this.players[1].hp == 0))
/*      */       {
/*  297 */         round = 0;
/*  298 */         Output.write("%d", new Object[] { Integer.valueOf(700) });
/*      */         
/*  300 */         for (int i = 0; i < 2; i++) {
/*  301 */           Player player = this.players[i];
/*  302 */           Card card = null;
/*  303 */           while (player.handCards.size() > 0) {
/*  304 */             card = (Card)player.handCards.remove(0);
/*  305 */             this.discardedCards.add(card);
/*  306 */             Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  307 */             Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */           }
/*      */           
/*  310 */           while (player.buffs.size() > 0) {
/*  311 */             card = deactivate((Card)player.buffs.get(0), i);
/*  312 */             this.discardedCards.add(card);
/*  313 */             Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  314 */             Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */           }
/*      */         }
/*      */         
/*  318 */         for (int i = 0; i < 2; i++)
/*      */         {
/*  320 */           Player player = this.players[i];
/*  321 */           if ((player.hp == 0) && 
/*  322 */             (player.loadHero() > 0)) {
/*  323 */             String heroNames = "";
/*  324 */             for (int c = 0; c < countHeroes(i); c++) {
/*  325 */               heroNames = heroNames + "|" + ((Attributes)player.attList.get(player.heroIdx + c)).name;
/*      */             }
/*  327 */             Output.write("%d|%d%s", new Object[] { Integer.valueOf(205), Integer.valueOf(i), heroNames });
/*  328 */             Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(i), Integer.valueOf(player.hp), Integer.valueOf(player.maxHp) });
/*  329 */             Output.write("%d|%d|%d", new Object[] { Integer.valueOf(303), Integer.valueOf(i), Integer.valueOf(player.attackTimes) });
/*  330 */             Output.write("%d|%d|%d", new Object[] { Integer.valueOf(304), Integer.valueOf(i), Integer.valueOf(player.drawCards) });
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  337 */       if ((attacker.heroIdx < 0) && (defender.heroIdx < 0)) {
/*  338 */         Output.write("%d", new Object[] { Integer.valueOf(899) });
/*  339 */         break; }
/*  340 */       if (defender.heroIdx < 0) {
/*  341 */         Output.write("%d|%d", new Object[] { Integer.valueOf(888), Integer.valueOf(this.attackerIdx) });
/*  342 */         break; }
/*  343 */       if (attacker.heroIdx < 0) {
/*  344 */         Output.write("%d|%d", new Object[] { Integer.valueOf(888), Integer.valueOf(this.defenderIdx) });
/*  345 */         break;
/*      */       }
/*      */       
/*  348 */       round++;
/*      */       
/*  350 */       int tmp = this.attackerIdx;
/*  351 */       this.attackerIdx = this.defenderIdx;
/*  352 */       this.defenderIdx = tmp;
/*      */     }
/*  354 */     Output.write("%d", new Object[] { Integer.valueOf(999) });
/*      */   }
/*      */   
/*      */   void shuffle(int times) {
/*  358 */     List<Card> t1 = new ArrayList();
/*  359 */     List<Card> t2 = new ArrayList();
/*      */     
/*      */ 
/*  362 */     while (!this.cardStore.isEmpty()) {
/*  363 */       int p = (int)(Math.random() * this.cardStore.size());
/*  364 */       int q = p % 2;
/*      */       
/*  366 */       if (q > 0) {
/*  367 */         t1.add((Card)this.cardStore.remove(p));
/*      */       } else {
/*  369 */         t2.add((Card)this.cardStore.remove(p));
/*      */       }
/*      */     }
/*  372 */     for (int t = 0; t < times; t++) {
/*  373 */       int p = this.cardStore.size() / 2;
/*  374 */       int i = 0;
/*  375 */       for (;;) { t1.add((Card)this.cardStore.remove(0));i++;
/*  374 */         if (i >= p)
/*      */           break;
/*      */       }
/*      */       for (;;) {
/*  378 */         this.cardStore.add((Card)t2.remove(0));
/*  377 */         if (t2.isEmpty())
/*      */           break;
/*      */       }
/*      */       do {
/*  381 */         this.cardStore.add((Card)t1.remove(0));
/*  382 */         this.cardStore.add((Card)t2.remove(0));
/*  380 */         if (t1.isEmpty()) break; } while (!t2.isEmpty());
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  385 */       while (!t1.isEmpty()) {
/*  386 */         this.cardStore.add((Card)t1.remove(0));
/*      */       }
/*  388 */       while (!t2.isEmpty()) {
/*  389 */         this.cardStore.add((Card)t2.remove(0));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPlayer(int index, String playerName)
/*      */   {
/*  402 */     Player player = this.players[index];
/*  403 */     player.name = playerName;
/*      */   }
/*      */   
/*      */   void use(Card... cards) {
/*  407 */     if ((cards.length == 0) || ((cards.length > 1) && (cards[0].type < 2)) || ((cards.length > 2) && (cards[0].type == 2))) {
/*      */       try {
/*  409 */         throw new RuntimeException("Incorrect number of parameter.");
/*      */       } catch (Exception e) {
/*  411 */         e.printStackTrace();
/*  412 */         System.exit(-1);
/*      */       }
/*      */     }
/*  415 */     switch (cards[0].type) {
/*      */     case 0: 
/*  417 */       useType0(cards[0]);
/*  418 */       break;
/*      */     case 1: 
/*  420 */       useType1(cards[0]);
/*  421 */       break;
/*      */     case 2: 
/*  423 */       if (cards.length == 1) {
/*  424 */         useType2(cards[0], null);
/*      */       } else
/*  426 */         useType2(cards[0], cards[1]);
/*      */       break;
/*      */     }
/*      */   }
/*      */   
/*      */   void deactivate(Card card) {
/*  432 */     if (this.stage != Stage.Action) {
/*  433 */       Output.write("%d|在%s階段，你不能除下【%s】。", new Object[] { Integer.valueOf(200), this.stage.chiName, card });
/*  434 */       return;
/*      */     }
/*  436 */     if (deactivate(card, this.attackerIdx) != null) {
/*  437 */       this.discardedCards.add(card);
/*  438 */       Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  439 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */     }
/*      */   }
/*      */   
/*      */   Card deactivate(Card card, int index)
/*      */   {
/*  445 */     Player player = this.players[index];
/*  446 */     Card cc = null;
/*  447 */     for (int i = 0; i < player.buffs.size(); i++) {
/*  448 */       cc = (Card)player.buffs.get(i);
/*  449 */       if (cc == card) {
/*  450 */         player.buffs.remove(i);
/*      */         
/*  452 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(501), Integer.valueOf(index), Integer.valueOf(card.id) });
/*      */         
/*  454 */         break;
/*      */       }
/*  456 */       cc = null;
/*      */     }
/*  458 */     if (cc == null) {
/*  459 */       Output.write("%d|【%s】並沒有裝備【%s】。", new Object[] { Integer.valueOf(200), Integer.valueOf(index), card.chiName });
/*  460 */       return null;
/*      */     }
/*  462 */     switch (card) {
/*      */     case Defense: 
/*  464 */       this.players[index]._attackTimes = ((Attributes)this.players[index].attList.get(this.players[index].heroIdx)).attackTimes;
/*  465 */       this.players[index].attackTimes = Math.min(this.players[index].attackTimes, this.players[index]._attackTimes);
/*  466 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(303), Integer.valueOf(this.attackerIdx), Integer.valueOf(this.players[index].attackTimes) });
/*  467 */       break;
/*      */     case Grab: 
/*  469 */       this.players[index].axe = ((Attributes)this.players[index].attList.get(this.players[index].heroIdx)).axe;
/*  470 */       break;
/*      */     case Repeal: 
/*  472 */       this.players[index].shield = ((Attributes)this.players[index].attList.get(this.players[index].heroIdx)).shield;
/*  473 */       break;
/*      */     case Heal: 
/*  475 */       this.players[index].maxHp = ((Attributes)this.players[index].attList.get(this.players[index].heroIdx)).maxHp;
/*  476 */       this.players[index].hp = Math.min(this.players[index].hp, this.players[index].maxHp);
/*  477 */       Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(index), Integer.valueOf(this.players[index].hp), Integer.valueOf(this.players[index].maxHp) });
/*  478 */       break;
/*      */     }
/*      */     
/*      */     
/*  482 */     return card;
/*      */   }
/*      */   
/*      */   private Card removeHandCard(Card card, int index) {
/*  486 */     Card c = null;
/*  487 */     Player player = this.players[index];
/*      */     
/*  489 */     for (int i = 0; i < player.handCards.size(); i++) {
/*  490 */       c = (Card)player.handCards.get(i);
/*  491 */       if (card == c) {
/*  492 */         player.handCards.remove(i);
/*  493 */         break;
/*      */       }
/*  495 */       c = null;
/*      */     }
/*  497 */     return c;
/*      */   }
/*      */   
/*      */   private void attack() {
/*  501 */     if (this.stage != Stage.Action) {
/*  502 */       Output.write("%d|在%s階段，你不能進行攻擊。", new Object[] { Integer.valueOf(200), this.stage.chiName });
/*  503 */       return;
/*      */     }
/*      */     
/*  506 */     Card card = null;
/*  507 */     Player attacker = this.players[this.attackerIdx];
/*  508 */     Player defender = this.players[this.defenderIdx];
/*      */     
/*  510 */     if (attacker.attackTimes == 0) {
/*  511 */       Output.write("%d|你不能再進行攻擊了。", new Object[] { Integer.valueOf(200) });
/*  512 */       return;
/*      */     }
/*      */     
/*  515 */     card = removeHandCard(Card.Attack, this.attackerIdx);
/*  516 */     if (card == null) {
/*  517 */       if (attacker.heroName.equals("趙雲")) {
/*  518 */         card = removeHandCard(Card.Defense, this.attackerIdx);
/*  519 */         if (card == null) {
/*  520 */           Output.write("%d|你沒有【%s】或【%s】可以使用。", new Object[] { Integer.valueOf(200), Card.Attack.chiName, Card.Defense.chiName });
/*      */         }
/*      */       }
/*      */       else {
/*  524 */         Output.write("%d|你沒有【%s】可以使用。", new Object[] { Integer.valueOf(200), Card.Attack.chiName });
/*  525 */         return;
/*      */       }
/*      */     }
/*      */     
/*  529 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(104), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*  530 */     Output.write("%d|%d", new Object[] { Integer.valueOf(401), Integer.valueOf(this.attackerIdx) });
/*      */     
/*  532 */     this.discardedCards.add(card);
/*  533 */     Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  534 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */     
/*  536 */     attacker.attackTimes -= 1;
/*  537 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(303), Integer.valueOf(this.attackerIdx), Integer.valueOf(attacker.attackTimes) });
/*      */     
/*  539 */     this.stage = Stage.BeingAttack;
/*      */     
/*  541 */     defender.beingAttack();
/*      */     
/*  543 */     boolean axeOn = false;
/*  544 */     int attackScore = this.rNums[this.rN];
/*  545 */     this.rN = ((this.rN + 1) % this.rNums.length);
/*      */     
/*  547 */     if (attackScore <= attacker.axe) {
/*  548 */       Output.write("%d|%d", new Object[] { Integer.valueOf(600), Integer.valueOf(this.attackerIdx) });
/*  549 */       axeOn = true;
/*      */     }
/*      */     
/*  552 */     if (this.defenseOn) {
/*  553 */       int defenseScore = this.rNums[this.rN];
/*  554 */       this.rN = ((this.rN + 1) % this.rNums.length);
/*  555 */       boolean shieldOn = false;
/*  556 */       if (defenseScore <= defender.shield) {
/*  557 */         Output.write("%d|%d", new Object[] { Integer.valueOf(601), Integer.valueOf(this.defenderIdx) });
/*  558 */         shieldOn = true;
/*      */       }
/*      */       
/*  561 */       if ((axeOn) && (!shieldOn)) {
/*  562 */         getHurt(this.defenderIdx);
/*  563 */       } else if ((!axeOn) && (shieldOn)) {
/*  564 */         getHurt(this.attackerIdx);
/*      */       } else {
/*  566 */         Output.write("%d", new Object[] { Integer.valueOf(602) });
/*      */       }
/*      */       
/*  569 */       this.defenseOn = false;
/*      */     } else {
/*  571 */       getHurt(this.defenderIdx);
/*      */     }
/*      */     
/*  574 */     this.stage = Stage.Action;
/*      */   }
/*      */   
/*      */   private void getHurt(int index) {
/*  578 */     Player player = this.players[index];
/*  579 */     player.hp = ((int)Math.max(0.0F, player.hp - 100.0F * this.players[((index + 1) % 2)].power / player.power));
/*  580 */     Output.write("%d|%d", new Object[] { Integer.valueOf(400), Integer.valueOf(index) });
/*  581 */     Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(index), Integer.valueOf(player.hp), Integer.valueOf(player.maxHp) });
/*      */   }
/*      */   
/*      */   private void defense() {
/*  585 */     if (this.stage != Stage.BeingAttack) {
/*  586 */       Output.write("%d|在%s階段，你不能使用【%s】。", new Object[] { Integer.valueOf(200), this.stage.chiName, Card.Defense });
/*  587 */       return;
/*      */     }
/*      */     
/*  590 */     Card card = removeHandCard(Card.Defense, this.defenderIdx);
/*      */     
/*  592 */     if (card == null) {
/*  593 */       Player defender = this.players[this.defenderIdx];
/*  594 */       if (defender.heroName.equals("趙雲")) {
/*  595 */         card = removeHandCard(Card.Attack, this.defenderIdx);
/*  596 */         if (card == null) {
/*  597 */           Output.write("%d|你沒有【%s】或【%s】可以使用。", new Object[] { Integer.valueOf(200), Card.Attack.chiName, Card.Defense.chiName });
/*      */         }
/*      */       }
/*      */       else {
/*  601 */         Output.write("%d|你沒有閃避可以使用。", new Object[] { Integer.valueOf(200) });
/*  602 */         return;
/*      */       }
/*      */     }
/*      */     
/*  606 */     this.defenseOn = true;
/*  607 */     this.discardedCards.add(card);
/*  608 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(104), Integer.valueOf(this.defenderIdx), Integer.valueOf(card.id) });
/*  609 */     Output.write("%d|%d", new Object[] { Integer.valueOf(402), Integer.valueOf(this.defenderIdx) });
/*  610 */     Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  611 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */   }
/*      */   
/*      */   private void heal()
/*      */   {
/*  616 */     if (this.stage != Stage.Action) {
/*  617 */       Output.write("%d|在%s階段，你不能使用【%s】。", new Object[] { Integer.valueOf(200), this.stage.chiName, Card.Heal });
/*  618 */       return;
/*      */     }
/*      */     
/*  621 */     Player attacker = this.players[this.attackerIdx];
/*  622 */     Card card = removeHandCard(Card.Heal, this.attackerIdx);
/*  623 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(104), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*      */     
/*  625 */     if (card != Card.Heal) {
/*  626 */       Output.write("%d|你沒有補藥可以使用。", new Object[] { Integer.valueOf(200) });
/*  627 */       return;
/*      */     }
/*      */     
/*  630 */     attacker.hp = Math.min(attacker.hp + 100, attacker.maxHp);
/*  631 */     this.discardedCards.add(card);
/*      */     
/*  633 */     Output.write("%d|%d", new Object[] { Integer.valueOf(403), Integer.valueOf(this.attackerIdx) });
/*  634 */     Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(this.attackerIdx), Integer.valueOf(attacker.hp), Integer.valueOf(attacker.maxHp) });
/*  635 */     Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  636 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */   }
/*      */   
/*      */   void useType0(Card card)
/*      */   {
/*  641 */     switch (card) {
/*      */     case Agility: 
/*  643 */       attack();
/*  644 */       break;
/*      */     case Attack: 
/*  646 */       defense();
/*  647 */       break;
/*      */     case Axe: 
/*  649 */       heal();
/*      */     }
/*      */   }
/*      */   
/*      */   void useType1(Card card)
/*      */   {
/*  655 */     Player attacker = this.players[this.attackerIdx];
/*  656 */     Card cc = removeHandCard(card, this.attackerIdx);
/*  657 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(104), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*      */     
/*  659 */     if (cc == null) {
/*  660 */       Output.write("%d|你沒有%s可以使用。", new Object[] { Integer.valueOf(200), card });
/*  661 */       return;
/*      */     }
/*      */     
/*  664 */     if (isActive(card)) {
/*  665 */       Card dc = deactivate(card, this.attackerIdx);
/*  666 */       this.discardedCards.add(dc);
/*  667 */       Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  668 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */     }
/*      */     
/*  671 */     attacker.buffs.add(card);
/*  672 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(500), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*      */     
/*  674 */     switch (card) {
/*      */     case Defense: 
/*  676 */       attacker.attackTimes += 1;
/*  677 */       attacker._attackTimes += 1;
/*  678 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(303), Integer.valueOf(this.attackerIdx), Integer.valueOf(attacker.attackTimes) });
/*  679 */       break;
/*      */     case Grab: 
/*  681 */       attacker.axe = Math.min(attacker.axe + 30, 40);
/*  682 */       break;
/*      */     case Repeal: 
/*  684 */       attacker.shield = Math.min(attacker.shield + 30, 40);
/*  685 */       break;
/*      */     case Heal: 
/*  687 */       attacker.maxHp += 100;
/*  688 */       attacker.hp += 100;
/*  689 */       Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(this.attackerIdx), Integer.valueOf(attacker.hp), Integer.valueOf(attacker.maxHp) });
/*  690 */       break;
/*      */     }
/*      */     
/*      */     
/*  694 */     if (attacker.buffs.size() > 2) {
/*  695 */       Card dc = deactivate((Card)attacker.buffs.get(0), this.attackerIdx);
/*  696 */       this.discardedCards.add(dc);
/*  697 */       Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  698 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */     }
/*      */   }
/*      */   
/*      */   void useType2(Card card, Card target) {
/*  703 */     Card cc = removeHandCard(card, this.attackerIdx);
/*  704 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(104), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*      */     
/*  706 */     Player attacker = this.players[this.attackerIdx];
/*  707 */     Player defender = this.players[this.defenderIdx];
/*      */     
/*  709 */     if (cc == null) {
/*  710 */       Output.write("%d|你沒有【%s】可以使用。", new Object[] { Integer.valueOf(200), card });
/*  711 */       return;
/*      */     }
/*      */     
/*  714 */     if (card == Card.RepealX) {
/*  715 */       card = (Card)this.exchangedCards.remove(0);
/*      */     }
/*  717 */     this.discardedCards.add(card);
/*  718 */     Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  719 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */     
/*  721 */     if (target == null) {
/*  722 */       if (defender.handCards.size() == 0) {
/*  723 */         Output.write("%d|對方沒有手牌。", new Object[] { Integer.valueOf(200) });
/*  724 */         return;
/*      */       }
/*  726 */       int r = (int)(Math.random() * defender.handCards.size());
/*  727 */       target = (Card)defender.handCards.get(r);
/*  728 */       removeHandCard(target, this.defenderIdx);
/*  729 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(103), Integer.valueOf(this.defenderIdx), Integer.valueOf(target.id) });
/*      */       
/*  731 */       if (card == Card.Grab) {
/*  732 */         attacker.handCards.add(target);
/*  733 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(102), Integer.valueOf(this.attackerIdx), Integer.valueOf(target.id) });
/*      */       } else {
/*  735 */         this.discardedCards.add(target);
/*  736 */         Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(target.id) });
/*  737 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */       }
/*      */       
/*      */     }
/*  741 */     else if (isActiveOpp(target)) {
/*  742 */       deactivate(target, this.defenderIdx);
/*  743 */       if (card == Card.Grab) {
/*  744 */         attacker.handCards.add(target);
/*  745 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(102), Integer.valueOf(this.attackerIdx), Integer.valueOf(target.id) });
/*      */       } else {
/*  747 */         this.discardedCards.add(target);
/*  748 */         Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(target.id) });
/*  749 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */       }
/*      */     }
/*      */     else {
/*  753 */       Output.write("%d|對方並沒有裝備【%s】。", new Object[] { Integer.valueOf(200), card });
/*      */     }
/*      */   }
/*      */   
/*      */   void draw()
/*      */   {
/*  759 */     if (this.stage != Stage.Drawing) {
/*  760 */       Output.write("%d|在%s階段，你不能抽牌。", new Object[] { Integer.valueOf(200), this.stage.chiName });
/*  761 */       return;
/*      */     }
/*  763 */     if (!this.players[this.attackerIdx].canDrawCards) {
/*  764 */       Output.write("%d|你不能再抽牌。", new Object[] { Integer.valueOf(200) });
/*  765 */       return;
/*      */     }
/*      */     
/*  768 */     _draw(this.players[this.attackerIdx].drawCards, this.attackerIdx);
/*  769 */     this.players[this.attackerIdx].canDrawCards = false; }
/*      */   
/*      */   private void _draw(int times, int index) { int cF;
/*      */     int cH;
/*      */     int cD;
/*  774 */     int cA = cD = cH = cF = 0;
/*  775 */     for (int t = 0; t < times; t++) {
/*  776 */       if (this.cardStore.size() == 0) {
/*  777 */         this.cardStore.addAll(this.discardedCards);
/*  778 */         this.discardedCards.clear();
/*  779 */         shuffle(5);
/*  780 */         Output.write("%d|clear", new Object[] { Integer.valueOf(101) });
/*  781 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */       }
/*      */       
/*      */ 
/*  785 */       int p = (int)(Math.random() * this.cardStore.size());
/*      */       
/*  787 */       int loop = 0;
/*  788 */       while (((((Card)this.cardStore.get(p)).type > 0) && (cF > 0)) || ((this.cardStore.get(p) == Card.Heal) && (cH > 0)) || 
/*  789 */         ((this.cardStore.get(p) == Card.Attack) && (cA > 1)) || ((this.cardStore.get(p) == Card.Defense) && (cD > 1))) {
/*  790 */         loop++;
/*  791 */         p = (int)(Math.random() * this.cardStore.size());
/*  792 */         if (loop > 10) {
/*      */           break;
/*      */         }
/*      */       }
/*  796 */       Card card = (Card)this.cardStore.remove(p);
/*  797 */       this.players[index].handCards.add(card);
/*      */       
/*  799 */       if (card.type > 0) {
/*  800 */         cF++;
/*      */       } else {
/*  802 */         switch (card) {
/*      */         case Agility: 
/*  804 */           cA++;
/*  805 */           break;
/*      */         case Attack: 
/*  807 */           cD++;
/*  808 */           break;
/*      */         case Axe: 
/*  810 */           cH++;
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  815 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(102), Integer.valueOf(index), Integer.valueOf(card.id) });
/*  816 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */     }
/*      */   }
/*      */   
/*      */   void discard(Card card) {
/*  821 */     if (this.stage != Stage.Discarding) {
/*  822 */       Output.write("%d|在%s階段，你不能抽牌。", new Object[] { Integer.valueOf(200), this.stage.chiName });
/*  823 */       return;
/*      */     }
/*      */     
/*  826 */     Player attacker = this.players[this.attackerIdx];
/*  827 */     boolean discard = false;
/*  828 */     for (int i = 0; i < attacker.handCards.size(); i++) {
/*  829 */       Card hCard = (Card)attacker.handCards.get(i);
/*  830 */       if (hCard == card) {
/*  831 */         attacker.handCards.remove(i);
/*  832 */         this.discardedCards.add(hCard);
/*  833 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(103), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*  834 */         Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  835 */         Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */         
/*  837 */         discard = true;
/*  838 */         break;
/*      */       }
/*      */     }
/*      */     
/*  842 */     if (!discard)
/*  843 */       Output.write("%d|你手上沒有%s可以丟棄。", new Object[] { Integer.valueOf(200), card.chiName });
/*      */   }
/*      */   
/*      */   private void autoDiscard() {
/*  847 */     Player attacker = this.players[this.attackerIdx];
/*      */     
/*  849 */     int numCardAllowed = (int)Math.ceil(0.01D * attacker.hp);
/*  850 */     while (attacker.handCards.size() > numCardAllowed) {
/*  851 */       int r = (int)(Math.random() * attacker.handCards.size());
/*  852 */       Card card = (Card)attacker.handCards.remove(r);
/*  853 */       this.discardedCards.add(card);
/*  854 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(103), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/*  855 */       Output.write("%d|%d", new Object[] { Integer.valueOf(101), Integer.valueOf(card.id) });
/*  856 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(100), Integer.valueOf(this.cardStore.size()), Integer.valueOf(this.discardedCards.size()) });
/*      */     }
/*      */   }
/*      */   
/*      */   int getHp()
/*      */   {
/*  862 */     if (this.stage == Stage.BeingAttack) {
/*  863 */       return this.players[this.defenderIdx].hp;
/*      */     }
/*  865 */     return this.players[this.attackerIdx].hp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOppHp()
/*      */   {
/*  874 */     if (this.stage == Stage.BeingAttack) {
/*  875 */       return this.players[this.attackerIdx].hp;
/*      */     }
/*  877 */     return this.players[this.defenderIdx].hp;
/*      */   }
/*      */   
/*      */   int getMaxHp() {
/*  881 */     if (this.stage == Stage.BeingAttack) {
/*  882 */       return this.players[this.defenderIdx].maxHp;
/*      */     }
/*  884 */     return this.players[this.attackerIdx].maxHp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOppMaxHp()
/*      */   {
/*  893 */     if (this.stage == Stage.BeingAttack) {
/*  894 */       return this.players[this.attackerIdx].maxHp;
/*      */     }
/*  896 */     return this.players[this.defenderIdx].maxHp;
/*      */   }
/*      */   
/*      */   int getAttackTimes() {
/*  900 */     if (this.stage == Stage.BeingAttack) {
/*  901 */       return this.players[this.defenderIdx].attackTimes;
/*      */     }
/*  903 */     return this.players[this.attackerIdx].attackTimes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOppAttackTimes()
/*      */   {
/*  912 */     if (this.stage == Stage.BeingAttack) {
/*  913 */       return this.players[this.attackerIdx].attackTimes;
/*      */     }
/*  915 */     return this.players[this.defenderIdx].attackTimes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int countNonReleasedCards()
/*      */   {
/*  924 */     return this.cardStore.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int countDiscardedCards()
/*      */   {
/*  933 */     return this.discardedCards.size();
/*      */   }
/*      */   
/*      */   private int countHandCards(Card card, int idx) {
/*  937 */     int count = 0;
/*  938 */     List<Card> handCards = this.players[idx].handCards;
/*      */     
/*  940 */     for (Card cc : handCards) {
/*  941 */       if (cc == card)
/*  942 */         count++;
/*      */     }
/*  944 */     return count;
/*      */   }
/*      */   
/*      */   private int countHandCards(int idx) {
/*  948 */     return this.players[idx].handCards.size();
/*      */   }
/*      */   
/*      */   int countHandCards() {
/*  952 */     return countHandCards(this.stage == Stage.BeingAttack ? this.defenderIdx : this.attackerIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int countOppHandCards()
/*      */   {
/*  961 */     return countHandCards(this.stage == Stage.BeingAttack ? this.attackerIdx : this.defenderIdx);
/*      */   }
/*      */   
/*      */   int countHandCards(Card card) {
/*  965 */     return countHandCards(card, this.stage == Stage.BeingAttack ? this.defenderIdx : this.attackerIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int countFuncCards()
/*      */   {
/*  974 */     List<Card> handCards = null;
/*  975 */     if (this.stage == Stage.BeingAttack)
/*      */     {
/*  977 */       handCards = this.players[this.defenderIdx].handCards;
/*      */     } else {
/*  979 */       handCards = this.players[this.attackerIdx].handCards;
/*      */     }
/*  981 */     int count = 0;
/*  982 */     for (Card c : handCards) {
/*  983 */       if (c.type >= 1) {
/*  984 */         count++;
/*      */       }
/*      */     }
/*  987 */     return count;
/*      */   }
/*      */   
/*      */   Card[] getBuffList(int idx) {
/*  991 */     Card[] cards = new Card[this.players[idx].buffs.size()];
/*      */     
/*  993 */     this.players[idx].buffs.toArray(cards);
/*      */     
/*  995 */     return cards;
/*      */   }
/*      */   
/*      */   Card[] getBuffList() {
/*  999 */     return getBuffList(this.stage == Stage.BeingAttack ? this.defenderIdx : this.attackerIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Card[] getOppBuffList()
/*      */   {
/* 1008 */     return getBuffList(this.stage == Stage.BeingAttack ? this.attackerIdx : this.defenderIdx);
/*      */   }
/*      */   
/*      */   private int countBuffs(int idx) {
/* 1012 */     return this.players[idx].buffs.size();
/*      */   }
/*      */   
/*      */   int countBuffs() {
/* 1016 */     return countBuffs(this.stage == Stage.BeingAttack ? this.defenderIdx : this.attackerIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int countOppBuffs()
/*      */   {
/* 1025 */     return countBuffs(this.stage == Stage.BeingAttack ? this.attackerIdx : this.defenderIdx);
/*      */   }
/*      */   
/*      */   private boolean isActive(Card card, int idx) {
/* 1029 */     boolean ret = false;
/* 1030 */     List<Card> buffs = this.players[idx].buffs;
/* 1031 */     for (Card cc : buffs) {
/* 1032 */       if (cc == card) {
/* 1033 */         ret = true;
/* 1034 */         break;
/*      */       }
/*      */     }
/* 1037 */     return ret;
/*      */   }
/*      */   
/*      */   boolean isActive(Card card) {
/* 1041 */     return isActive(card, this.stage == Stage.BeingAttack ? this.defenderIdx : this.attackerIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActiveOpp(Card card)
/*      */   {
/* 1053 */     return isActive(card, this.stage == Stage.BeingAttack ? this.attackerIdx : this.defenderIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int countOppHeroes()
/*      */   {
/* 1062 */     if (this.stage == Stage.BeingAttack) {
/* 1063 */       return countHeroes(this.attackerIdx);
/*      */     }
/* 1065 */     return countHeroes(this.defenderIdx);
/*      */   }
/*      */   
/*      */   int countHeroes(int index) {
/* 1069 */     return this.players[index].heroes.size() - this.players[index].heroIdx;
/*      */   }
/*      */   
/*      */   void specZhangLiao()
/*      */   {
/* 1074 */     if (!this.players[this.attackerIdx].canDrawCards) {
/* 1075 */       Output.write("%d|你不能使用技能。", new Object[] { Integer.valueOf(200) });
/* 1076 */       return;
/*      */     }
/*      */     
/* 1079 */     if (this.stage != Stage.Drawing) {
/* 1080 */       Output.write("%d|在%s階段，你不能使用技能。", new Object[] { Integer.valueOf(200), this.stage.chiName });
/* 1081 */       return;
/*      */     }
/*      */     
/* 1084 */     Player attacker = this.players[this.attackerIdx];
/* 1085 */     Player defender = this.players[this.defenderIdx];
/* 1086 */     int r = (int)(Math.random() * 100.0D) % 2 + 1;
/* 1087 */     for (int i = 0; i < r; i++) {
/* 1088 */       r = (int)(Math.random() * defender.handCards.size());
/* 1089 */       Card target = (Card)defender.handCards.get(r);
/* 1090 */       removeHandCard(target, this.defenderIdx);
/* 1091 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(103), Integer.valueOf(this.defenderIdx), Integer.valueOf(target.id) });
/* 1092 */       attacker.handCards.add(target);
/* 1093 */       Output.write("%d|%d|%d", new Object[] { Integer.valueOf(102), Integer.valueOf(this.attackerIdx), Integer.valueOf(target.id) });
/*      */     }
/* 1095 */     attacker.canDrawCards = false;
/* 1096 */     attacker.canSpec = false;
/*      */   }
/*      */   
/*      */   void specXuChu()
/*      */   {
/* 1101 */     if (!this.players[this.attackerIdx].canDrawCards) {
/* 1102 */       Output.write("%d|你不能使用技能。", new Object[] { Integer.valueOf(200) });
/* 1103 */       return;
/*      */     }
/*      */     
/* 1106 */     if (this.stage != Stage.Drawing) {
/* 1107 */       Output.write("%d|在%s階段，你不能使用技能。", new Object[] { Integer.valueOf(200), this.stage.chiName });
/* 1108 */       return;
/*      */     }
/*      */     
/* 1111 */     Player attacker = this.players[this.attackerIdx];
/* 1112 */     attacker.power = 2;
/* 1113 */     Output.write("%d|%d", new Object[] { Integer.valueOf(1001), Integer.valueOf(this.attackerIdx) });
/* 1114 */     _draw(attacker.drawCards - 1, this.attackerIdx);
/* 1115 */     attacker.canDrawCards = false;
/* 1116 */     attacker.canSpec = false;
/*      */   }
/*      */   
/*      */   void specHuangeGai() {
/* 1120 */     if (this.stage != Stage.Action) {
/* 1121 */       Output.write("%d|在%s階段，你不能使用技能。", new Object[] { Integer.valueOf(200), this.stage.chiName });
/* 1122 */       return;
/*      */     }
/*      */     
/* 1125 */     Player player = this.players[this.attackerIdx];
/*      */     
/* 1127 */     if (player.hp < player.maxHp / 2) {
/* 1128 */       Output.write("%d|血量少於最大值的一半，不能使用技能。", new Object[] { Integer.valueOf(200) });
/* 1129 */       return;
/*      */     }
/*      */     
/* 1132 */     if (player.handCards.size() >= 8) {
/* 1133 */       Output.write("%d|手牌大多，不能使用技能。", new Object[] { Integer.valueOf(200) });
/* 1134 */       return;
/*      */     }
/*      */     
/* 1137 */     player.hp -= player.hp / 4;
/* 1138 */     Output.write("%d|%d", new Object[] { Integer.valueOf(400), Integer.valueOf(this.attackerIdx) });
/* 1139 */     Output.write("%d|%d|%d|%d", new Object[] { Integer.valueOf(302), Integer.valueOf(this.attackerIdx), Integer.valueOf(player.hp), Integer.valueOf(player.maxHp) });
/* 1140 */     _draw(player.drawCards, this.attackerIdx);
/*      */   }
/*      */   
/* 1143 */   List<Card> exchangedCards = new ArrayList();
/*      */   
/*      */   void specGanNing(Card card) {
/* 1146 */     if (((card.type != 1) && (card != Card.Heal)) || (card == Card.RepealX)) {
/* 1147 */       Output.write("%d|【%d】不能用作轉換。", new Object[] { Integer.valueOf(200), Integer.valueOf(card.id) });
/* 1148 */       return;
/*      */     }
/* 1150 */     Player attacker = this.players[this.attackerIdx];
/* 1151 */     Card cc = removeHandCard(card, this.attackerIdx);
/* 1152 */     if (cc == null) {
/* 1153 */       Output.write("%d|你沒有【%d】用作轉換。", new Object[] { Integer.valueOf(200), Integer.valueOf(card.id) });
/* 1154 */       return;
/*      */     }
/* 1156 */     attacker.handCards.add(Card.RepealX);
/* 1157 */     this.exchangedCards.add(card);
/* 1158 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(103), Integer.valueOf(this.attackerIdx), Integer.valueOf(card.id) });
/* 1159 */     Output.write("%d|%d|%d", new Object[] { Integer.valueOf(102), Integer.valueOf(this.attackerIdx), Integer.valueOf(Card.RepealX.id) });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void mute()
/*      */   {
/* 1166 */     this.aniPlayer.mute();
/*      */   }
/*      */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\GameMaster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */