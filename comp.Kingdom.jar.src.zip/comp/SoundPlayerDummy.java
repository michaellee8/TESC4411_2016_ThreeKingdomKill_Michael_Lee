package comp;

class SoundPlayerDummy
  implements SoundPlayerIF
{
  public void playA(String key) {}
  
  public void playLoop(String key) {}
  
  public void pause(String key) {}
  
  public void stopAll() {}
}


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\SoundPlayerDummy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */