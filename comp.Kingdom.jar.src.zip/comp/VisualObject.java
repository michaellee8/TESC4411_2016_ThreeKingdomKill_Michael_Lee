/*    */ package comp;
/*    */ 
/*    */ import java.awt.Graphics2D;
/*    */ import javax.swing.JComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class VisualObject
/*    */ {
/* 22 */   float x = 0.0F; float y = 0.0F;
/* 23 */   int posX = 8; int posY = 1;
/* 24 */   double zoom = 1.0D;
/* 25 */   float alpha = 1.0F;
/* 26 */   boolean flipX = false;
/* 27 */   boolean flipY = false;
/* 28 */   Object tag = null;
/*    */   
/*    */   abstract double getW();
/*    */   
/*    */   abstract double getH();
/*    */   
/*    */   abstract void draw(Graphics2D paramGraphics2D);
/*    */   
/* 36 */   JComponent canvas = null;
/*    */   
/*    */   VisualObject(JComponent canvas) {
/* 39 */     this.canvas = canvas; }
/*    */   
/*    */ 
/*    */   void onClick() {}
/*    */   
/*    */   void setPosition(float x, float y, int... canvasPositions)
/*    */   {
/* 46 */     this.x = x;
/* 47 */     this.y = y;
/* 48 */     int[] arrayOfInt; int j = (arrayOfInt = canvasPositions).length; for (int i = 0; i < j; i++) { int p = arrayOfInt[i];
/* 49 */       switch (p) {
/*    */       case 1: 
/*    */       case 2: 
/*    */       case 4: 
/* 53 */         this.posY = p;
/* 54 */         break;
/*    */       case 8: 
/*    */       case 16: 
/*    */       case 32: 
/* 58 */         this.posX = p;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   float getX()
/*    */   {
/* 65 */     float xx = this.x;
/* 66 */     switch (this.posX) {
/*    */     case 32: 
/* 68 */       xx = this.canvas.getWidth() - this.x;
/*    */     case 16: 
/* 70 */       xx = this.canvas.getWidth() / 2 - this.x;
/*    */     }
/* 72 */     return xx;
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\VisualObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */