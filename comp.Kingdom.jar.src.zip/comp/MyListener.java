/*    */ package comp;
/*    */ 
/*    */ import java.awt.event.MouseEvent;
/*    */ 
/*    */ 
/*    */ class MyListener
/*    */   extends AniMouseListener
/*    */ {
/*  9 */   AnimationPlayer player = null;
/* 10 */   GameMaster master = null;
/*    */   
/*    */   MyListener() {
/* 13 */     this.master = GameMaster.getInstance();
/* 14 */     this.player = this.master.aniPlayer;
/*    */   }
/*    */   
/*    */   public void mouseClicked(MouseEvent e)
/*    */   {
/* 19 */     super.mouseClicked(e);
/* 20 */     int x = e.getX();
/* 21 */     int y = e.getY();
/*    */     
/* 23 */     for (VisualObject obj : this.player.buttons) {
/* 24 */       if ((x > obj.getX() - obj.getW() / 2.0D) && (x < obj.getX() + obj.getW() / 2.0D) && (y > obj.y - obj.getH() / 2.0D) && 
/* 25 */         (y < obj.y + obj.getH() / 2.0D)) {
/* 26 */         obj.onClick();
/* 27 */         synchronized (GameMaster.getInstance().thread) {
/* 28 */           GameMaster.getInstance().thread.notify();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\michael2\Downloads\comp.Kingdom.jar!\comp\MyListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */